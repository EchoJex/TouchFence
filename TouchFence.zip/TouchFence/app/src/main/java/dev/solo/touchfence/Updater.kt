package dev.solo.touchfence

import android.app.Activity
import android.app.AlertDialog
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * One-tap in-app updater. Pulls the newest CI build straight from the repo's
 * GitHub Releases and hands it to the system installer — no browser, no manual
 * download/unzip, no uninstall (the committed keystore means the new APK
 * installs right over the old one).
 *
 * Android does not permit a sideloaded app to install itself silently, so the
 * flow ends at a single system "Update this app?" confirmation. Everything up
 * to that point is automatic.
 *
 * Framework APIs only — HttpURLConnection + org.json + PackageInstaller — so
 * the project's zero-third-party-dependencies rule still holds. The one new
 * cost is the INTERNET permission (this is the app's only network use) plus
 * REQUEST_INSTALL_PACKAGES.
 */
object Updater {

    /** CI keeps a single rolling "latest" release; this always points at the newest build. */
    private const val API_LATEST =
        "https://api.github.com/repos/EchoJex/TouchFence/releases/latest"

    /** All releases, so the picker can list per-branch channels (tags "ch-<branch>"). */
    private const val API_RELEASES =
        "https://api.github.com/repos/EchoJex/TouchFence/releases?per_page=50"

    /** Internal broadcast the PackageInstaller session reports its status back on. */
    private const val INSTALL_ACTION = "dev.solo.touchfence.INSTALL_STATUS"

    private val ui = Handler(Looper.getMainLooper())

    @Volatile private var busy = false
    @Volatile private var receiverRegistered = false

    /** Installed versionCode, or 0 if it can't be read. */
    private fun installedCode(context: Context): Long = try {
        context.packageManager.getPackageInfo(context.packageName, 0).longVersionCode
    } catch (t: Throwable) {
        0L
    }

    /**
     * Check GitHub for a newer build; if there is one, download it and launch
     * the installer. Network and IO run off the main thread; user-facing
     * messages are posted back to it.
     */
    fun checkAndUpdate(context: Context) {
        if (busy) {
            toast(context, "Update already in progress…")
            return
        }
        // Android gates self-install behind a per-app "install unknown apps" toggle.
        if (!context.packageManager.canRequestPackageInstalls()) {
            toast(context, "Allow TouchFence to install apps, then tap Check for updates again")
            try {
                context.startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:${context.packageName}")
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (t: Throwable) {
                // That settings screen isn't available on this build; nothing else to do.
            }
            return
        }
        busy = true
        val app = context.applicationContext
        toast(app, "Checking for updates…")
        Thread {
            try {
                val (latestCode, apkUrl) = fetchLatest()
                val installed = installedCode(app)
                when {
                    apkUrl == null -> toast(app, "No build published yet")
                    latestCode <= installed -> toast(app, "Already up to date (build $installed)")
                    else -> {
                        toast(app, "Downloading build $latestCode…")
                        val apk = download(apkUrl)
                        install(app, apk, latestCode)
                    }
                }
            } catch (t: Throwable) {
                toast(app, "Update check failed: ${t.message ?: t.javaClass.simpleName}")
            } finally {
                busy = false
            }
        }.start()
    }

    /** One channel = one branch's newest build. */
    private data class Channel(val branch: String, val code: Long, val apkUrl: String)

    /**
     * Show a single-choice picker of build channels (main + any active branch)
     * and install the one chosen. Default tap on the button still targets the
     * literal latest via [checkAndUpdate]; this is the "pick a branch" path.
     */
    fun pickChannelAndUpdate(activity: Activity) {
        if (busy) {
            toast(activity, "Update already in progress…")
            return
        }
        if (!activity.packageManager.canRequestPackageInstalls()) {
            toast(activity, "Allow TouchFence to install apps, then try again")
            try {
                activity.startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:${activity.packageName}")
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (t: Throwable) {
                // Setting screen unavailable.
            }
            return
        }
        busy = true
        val app = activity.applicationContext
        toast(app, "Loading build channels…")
        Thread {
            val channels = try {
                fetchChannels()
            } catch (t: Throwable) {
                emptyList()
            }
            ui.post {
                if (channels.isEmpty()) {
                    toast(app, "No channels found")
                    busy = false
                    return@post
                }
                showPicker(activity, app, channels)
            }
        }.start()
    }

    private fun showPicker(activity: Activity, app: Context, channels: List<Channel>) {
        val installed = installedCode(app)
        val labels = channels.mapIndexed { i, c ->
            val latest = if (i == 0) " (latest)" else ""
            val rel = when {
                c.code > installed -> "newer"
                c.code == installed -> "installed"
                else -> "older"
            }
            "${c.branch} — build ${c.code}$latest\n$rel"
        }.toTypedArray()
        try {
            AlertDialog.Builder(activity)
                .setTitle("Update from channel")
                .setSingleChoiceItems(labels, 0, null)
                .setPositiveButton("Update") { d, _ ->
                    val idx = (d as AlertDialog).listView.checkedItemPosition
                    d.dismiss()
                    val chosen = channels.getOrNull(idx)
                    if (chosen == null) {
                        busy = false
                    } else {
                        installChannel(app, chosen)
                    }
                }
                .setNegativeButton("Cancel") { d, _ -> d.dismiss(); busy = false }
                .setOnCancelListener { busy = false }
                .show()
        } catch (t: Throwable) {
            busy = false
            toast(app, "Couldn't open the picker")
        }
    }

    private fun installChannel(app: Context, c: Channel) {
        toast(app, "Downloading ${c.branch} build ${c.code}…")
        Thread {
            try {
                install(app, download(c.apkUrl), c.code)
            } catch (t: Throwable) {
                toast(app, "Update failed: ${t.message ?: t.javaClass.simpleName}")
            } finally {
                busy = false
            }
        }.start()
    }

    /** Reads /releases → one Channel per "ch-<branch>" release, newest first. */
    private fun fetchChannels(): List<Channel> {
        val conn = (URL(API_RELEASES).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("User-Agent", "TouchFence-Updater")
        }
        try {
            if (conn.responseCode != 200) throw RuntimeException("GitHub returned ${conn.responseCode}")
            val arr = JSONArray(conn.inputStream.bufferedReader().use { it.readText() })
            val out = ArrayList<Channel>()
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i)
                // Only per-branch channel releases; skip the rolling "latest" duplicate.
                if (!r.optString("tag_name").startsWith("ch-")) continue
                val body = r.optString("body")
                val branch = Regex("branch=(.+)").find(body)?.groupValues?.get(1)?.trim()
                    ?: r.optString("tag_name").removePrefix("ch-")
                var code = Regex("versionCode=(\\d+)")
                    .find(body)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                var apkUrl: String? = null
                val assets = r.optJSONArray("assets")
                if (assets != null) {
                    for (j in 0 until assets.length()) {
                        val a = assets.getJSONObject(j)
                        if (a.optString("name").endsWith(".apk")) {
                            apkUrl = a.optString("browser_download_url")
                            if (code == 0L) code = Regex("(\\d+)").find(a.optString("name"))?.value?.toLongOrNull() ?: 0L
                            break
                        }
                    }
                }
                if (apkUrl != null && code > 0) out.add(Channel(branch, code, apkUrl))
            }
            return out.sortedByDescending { it.code }
        } finally {
            conn.disconnect()
        }
    }

    /** Reads releases/latest → (versionCode, apkDownloadUrl?). */
    private fun fetchLatest(): Pair<Long, String?> {
        val conn = (URL(API_LATEST).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 15000
            setRequestProperty("Accept", "application/vnd.github+json")
            setRequestProperty("User-Agent", "TouchFence-Updater")
        }
        try {
            if (conn.responseCode != 200) {
                throw RuntimeException("GitHub returned ${conn.responseCode}")
            }
            val obj = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
            // CI writes "versionCode=NNNN" into the release notes.
            var code = Regex("versionCode=(\\d+)")
                .find(obj.optString("body"))?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            var apkUrl: String? = null
            val assets = obj.optJSONArray("assets")
            if (assets != null) {
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    val name = a.optString("name")
                    if (name.endsWith(".apk")) {
                        apkUrl = a.optString("browser_download_url")
                        // Fallback if the notes were missing: parse the code out of TouchFence-NNNN.apk.
                        if (code == 0L) {
                            code = Regex("(\\d+)").find(name)?.value?.toLongOrNull() ?: 0L
                        }
                        break
                    }
                }
            }
            return code to apkUrl
        } finally {
            conn.disconnect()
        }
    }

    /** Downloads the APK, following GitHub's redirect to its asset host. */
    private fun download(urlStr: String): ByteArray {
        var url = URL(urlStr)
        var redirects = 0
        while (true) {
            val conn = (url.openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = true
                connectTimeout = 20000
                readTimeout = 60000
                setRequestProperty("User-Agent", "TouchFence-Updater")
            }
            val code = conn.responseCode
            if (code in 301..308 && code != 304) {
                val loc = conn.getHeaderField("Location")
                conn.disconnect()
                if (loc == null || ++redirects > 5) throw RuntimeException("too many redirects")
                url = URL(url, loc)
                continue
            }
            if (code != 200) {
                conn.disconnect()
                throw RuntimeException("download HTTP $code")
            }
            try {
                return conn.inputStream.use { it.readBytes() }
            } finally {
                conn.disconnect()
            }
        }
    }

    /** Streams the APK into a PackageInstaller session and commits it. */
    private fun install(context: Context, apk: ByteArray, code: Long) {
        registerStatusReceiver(context)
        val installer = context.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(
            PackageInstaller.SessionParams.MODE_FULL_INSTALL
        )
        val sessionId = installer.createSession(params)
        val session = installer.openSession(sessionId)
        try {
            session.openWrite("touchfence-$code", 0, apk.size.toLong()).use { out ->
                out.write(apk)
                session.fsync(out)
            }
            val intent = Intent(INSTALL_ACTION).setPackage(context.packageName)
            val pi = PendingIntent.getBroadcast(
                context, sessionId, intent,
                PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            session.commit(pi.intentSender)
        } finally {
            session.close()
        }
    }

    /** One app-internal receiver that surfaces the installer's status. */
    private fun registerStatusReceiver(context: Context) {
        if (receiverRegistered) return
        receiverRegistered = true
        val app = context.applicationContext
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) {
                when (intent.getIntExtra(
                    PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE
                )) {
                    PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                        // Launch the system "Update this app?" confirmation.
                        val confirm = intent.getParcelableExtra(Intent.EXTRA_INTENT, Intent::class.java)
                        if (confirm != null) {
                            try {
                                app.startActivity(confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (t: Throwable) {
                                toast(app, "Couldn't open the installer")
                            }
                        }
                    }
                    PackageInstaller.STATUS_SUCCESS ->
                        toast(app, "Update installed")
                    else -> {
                        val msg = intent.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)
                        toast(app, "Install failed: ${msg ?: "cancelled"}")
                    }
                }
            }
        }
        app.registerReceiver(receiver, IntentFilter(INSTALL_ACTION), Context.RECEIVER_NOT_EXPORTED)
    }

    private fun toast(context: Context, msg: String) {
        ui.post { Toast.makeText(context, msg, Toast.LENGTH_LONG).show() }
    }
}
