package dev.solo.touchfence

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Control panel. Everything is deliberately anchored to the BOTTOM half of the
 * screen, because on this phone the top half can't be trusted to register taps.
 */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var grantButton: Button
    private lateinit var startStopButton: Button

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.rgb(18, 18, 20))

        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(dp(24), dp(24), dp(24), dp(32))

        val title = TextView(this)
        title.text = "TouchFence"
        title.textSize = 28f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(Color.WHITE)
        column.addView(title)

        status = TextView(this)
        status.textSize = 15f
        status.setTextColor(Color.rgb(190, 190, 195))
        status.setPadding(0, dp(8), 0, dp(16))
        column.addView(status)

        grantButton = addButton(column, "Grant overlay permission") {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        }

        addButton(column, "Draw or edit mask") {
            stopService(Intent(this, BlockerService::class.java))
            startActivity(Intent(this, DrawMaskActivity::class.java))
        }

        startStopButton = addButton(column, "Start blocking") {
            if (BlockerService.RUNNING) {
                stopService(Intent(this, BlockerService::class.java))
                // Service teardown is async-ish; refresh shortly after.
                startStopButton.postDelayed({ refresh() }, 250)
            } else {
                when {
                    !Settings.canDrawOverlays(this) ->
                        Toast.makeText(this, "Grant overlay permission first", Toast.LENGTH_SHORT).show()
                    MaskStore.load(this).isEmpty() ->
                        Toast.makeText(this, "Draw a mask first", Toast.LENGTH_SHORT).show()
                    else -> {
                        startForegroundService(
                            Intent(this, BlockerService::class.java)
                                .setAction(BlockerService.ACTION_START)
                        )
                        startStopButton.postDelayed({ refresh() }, 250)
                    }
                }
            }
        }

        addButton(column, "Clear saved mask") {
            stopService(Intent(this, BlockerService::class.java))
            MaskStore.clear(this)
            Toast.makeText(this, "Mask cleared", Toast.LENGTH_SHORT).show()
            startStopButton.postDelayed({ refresh() }, 250)
        }

        val hint = TextView(this)
        hint.text = "Controls live in the lower half of the screen on purpose. " +
                "If a zone ever traps you, the notification has Pause and Stop, " +
                "and rebooting into safe mode disables all overlays."
        hint.textSize = 13f
        hint.setTextColor(Color.rgb(140, 140, 148))
        hint.setPadding(0, dp(16), 0, 0)
        column.addView(hint)

        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.gravity = Gravity.BOTTOM
        root.addView(column, lp)

        setContentView(root)
    }

    private fun addButton(parent: LinearLayout, label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 17f
        b.minHeight = dp(56)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(10)
        parent.addView(b, lp)
        return b
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val overlayOk = Settings.canDrawOverlays(this)
        val zoneCount = MaskStore.load(this).size
        val running = BlockerService.RUNNING

        grantButton.visibility = if (overlayOk) android.view.View.GONE else android.view.View.VISIBLE
        startStopButton.text = if (running) "Stop blocking" else "Start blocking"

        val sb = StringBuilder()
        sb.append(if (overlayOk) "Overlay permission: granted" else "Overlay permission: NOT granted")
        sb.append("\n")
        sb.append(
            when (zoneCount) {
                0 -> "Mask: none saved yet"
                1 -> "Mask: 1 rectangle saved"
                else -> "Mask: $zoneCount rectangles saved"
            }
        )
        sb.append("\n")
        sb.append(if (running) "Blocking: ACTIVE" else "Blocking: off")
        status.text = sb.toString()
    }
}
