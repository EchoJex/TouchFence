package dev.solo.touchfence

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Control panel. Everything is deliberately anchored to the BOTTOM half of the
 * screen, because on this phone the top half can't be trusted to register taps.
 */
class MainActivity : Activity() {

    private lateinit var rootLayout: FrameLayout
    private lateinit var status: TextView
    private lateinit var menuColumn: LinearLayout
    private var startStopButton: Button? = null

    private enum class Screen { HOME, GHOST, CHECK, TOOLS }
    private var screen = Screen.HOME

    /** First-run guidance overlay; present only while no active mask exists. */
    private var onboard: View? = null
    private var onboardSkipped = false

    private val REQ_IMPORT = 7

    companion object {
        /** Measured bottom (portrait px) of this panel's dead/ghost row band:
         *  above this the digitizer no longer passes real touch and emits ghosts,
         *  so blocking 0..this is lossless. From the scratch-pad datasets. */
        const val DAMAGED_BAND_BOTTOM_PX = 685
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (QuickApply.onKey(this, keyCode)) return true
        return super.onKeyDown(keyCode, event)
    }

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_IMPORT) return
        val uri = data?.data ?: return
        val text = try {
            contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: ""
        } catch (t: Throwable) {
            ""
        }
        if (text.isBlank()) {
            Toast.makeText(this, "Couldn't read that file", Toast.LENGTH_SHORT).show()
            return
        }
        val count = MaskStore.importText(this, text)
        if (count == 0) {
            Toast.makeText(this, "No mask rectangles found in that file", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(
                this,
                "Imported $count zones \u2014 tap Start blocking to apply",
                Toast.LENGTH_LONG
            ).show()
        }
        refresh()
        maybeShowOnboarding()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        rootLayout = FrameLayout(this)
        rootLayout.setBackgroundColor(Color.rgb(18, 18, 20))

        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        column.setPadding(dp(24), dp(24), dp(24), dp(32))

        val logo = ImageView(this)
        logo.setImageResource(R.drawable.app_logo)
        val logoLp = LinearLayout.LayoutParams(dp(64), dp(64))
        column.addView(logo, logoLp)

        val title = TextView(this)
        title.text = "Ghost-TouchBlocker"
        title.textSize = 28f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(Color.WHITE)
        column.addView(title)

        status = TextView(this)
        status.textSize = 15f
        status.setTextColor(Color.rgb(190, 190, 195))
        status.setPadding(0, dp(8), 0, dp(16))
        column.addView(status)

        menuColumn = LinearLayout(this)
        menuColumn.orientation = LinearLayout.VERTICAL
        column.addView(menuColumn)

        val hint = TextView(this)
        hint.text = "Controls live in the lower half of the screen on purpose. " +
                "If a zone ever traps you, the notification has Pause and Stop, " +
                "and rebooting into safe mode disables all overlays."
        hint.textSize = 13f
        hint.setTextColor(Color.rgb(140, 140, 148))
        hint.setPadding(0, dp(16), 0, 0)
        column.addView(hint)

        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.gravity = Gravity.BOTTOM
        rootLayout.addView(column, lp)

        setContentView(rootLayout)
        showMenu(Screen.HOME)
        maybeAutoStart()
    }

    // ------------------------------------------------------------ menus (<=4 each)

    private fun showMenu(s: Screen) {
        screen = s
        menuColumn.removeAllViews()
        startStopButton = null
        when (s) {
            Screen.HOME -> buildHome()
            Screen.GHOST -> buildGhost()
            Screen.CHECK -> buildCheck()
            Screen.TOOLS -> buildTools()
        }
        refresh()
    }

    private fun buildHome() {
        if (!Settings.canDrawOverlays(this)) {
            addButton(menuColumn, "Grant overlay permission") {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        } else {
            startStopButton = addButton(menuColumn, "Start blocking") { toggleBlocking() }
        }
        addButton(menuColumn, "Click HERE for Ghost blocking") { showMenu(Screen.GHOST) }
        addButton(menuColumn, "Click HERE for screen check") { showMenu(Screen.CHECK) }
        addButton(menuColumn, "Tools & data") { showMenu(Screen.TOOLS) }
    }

    private fun buildGhost() {
        addButton(menuColumn, "Draw / edit blocking mask") {
            stopService(Intent(this, BlockerService::class.java))
            startActivity(Intent(this, DrawMaskActivity::class.java))
        }
        addButton(menuColumn, "Block damaged band (top)") { blockDamagedBand() }
        addButton(menuColumn, "Clear saved mask") {
            stopService(Intent(this, BlockerService::class.java))
            MaskStore.clear(this)
            Toast.makeText(this, "Mask cleared", Toast.LENGTH_SHORT).show()
            refreshSoon()
        }
        addButton(menuColumn, "\u2039 Back") { showMenu(Screen.HOME) }
    }

    private fun buildCheck() {
        addButton(menuColumn, "Map dead zones (draw where it works)") {
            stopService(Intent(this, BlockerService::class.java))
            startActivity(Intent(this, DeadZoneActivity::class.java))
        }
        addButton(menuColumn, "Touch test (scratch pad)") {
            stopService(Intent(this, BlockerService::class.java))
            startActivity(Intent(this, TouchTestActivity::class.java))
        }
        addButton(menuColumn, "\u2039 Back") { showMenu(Screen.HOME) }
    }

    private fun buildTools() {
        val export = addButton(menuColumn, "Export ghost data") {
            val name = LogStore.saveToDownloads(this, LogStore.buildExport(this))
            Toast.makeText(
                this,
                if (name != null) "Saved to Downloads as $name" else "Save failed",
                Toast.LENGTH_LONG
            ).show()
        }
        export.setOnLongClickListener {
            LogStore.clear(this)
            Toast.makeText(this, "Ghost log cleared", Toast.LENGTH_SHORT).show()
            true
        }
        addButton(menuColumn, "Import mask data") {
            val pick = Intent(Intent.ACTION_OPEN_DOCUMENT)
            pick.addCategory(Intent.CATEGORY_OPENABLE)
            pick.type = "*/*"
            try {
                startActivityForResult(pick, REQ_IMPORT)
            } catch (t: Throwable) {
                Toast.makeText(this, "No file picker available", Toast.LENGTH_SHORT).show()
            }
        }
        val upd = addButton(menuColumn, "Check for updates") { Updater.checkAndUpdate(this) }
        // Long-press to pick a specific channel (main / any branch); tap = latest.
        upd.setOnLongClickListener {
            Updater.pickChannelAndUpdate(this)
            true
        }
        addButton(menuColumn, "\u2039 Back") { showMenu(Screen.HOME) }
    }

    private fun toggleBlocking() {
        if (BlockerService.RUNNING) {
            stopService(Intent(this, BlockerService::class.java))
            refreshSoon()
            return
        }
        when {
            !Settings.canDrawOverlays(this) ->
                Toast.makeText(this, "Grant overlay permission first", Toast.LENGTH_SHORT).show()
            MaskStore.load(this).isEmpty() ->
                Toast.makeText(this, "Set up a mask first (Ghost blocking or screen check)", Toast.LENGTH_SHORT).show()
            else -> {
                startForegroundService(
                    Intent(this, BlockerService::class.java).setAction(BlockerService.ACTION_START)
                )
                refreshSoon()
            }
        }
    }

    /**
     * Default to blocking: on launch, if a mask exists and overlays are
     * permitted, start the service without waiting for a tap. Fires once per
     * launch, so an explicit Stop during the session is respected until the
     * next time the app is opened.
     */
    /**
     * One-tap mask for this panel's damaged top band: a single full-width rect
     * from y=0 to [DAMAGED_BAND_BOTTOM_PX], sized to the CURRENT resolution (so
     * it's aligned in whatever display mode is active). That region is dead to
     * real touch and the ghost source, so blocking it is lossless. Applies
     * immediately if overlays are permitted.
     */
    private fun blockDamagedBand() {
        val width = try {
            windowManager.currentWindowMetrics.bounds.width()
        } catch (t: Throwable) {
            resources.displayMetrics.widthPixels
        }
        MaskStore.save(this, listOf(Rect(0, 0, width, DAMAGED_BAND_BOTTOM_PX)))
        if (Settings.canDrawOverlays(this)) {
            startForegroundService(
                Intent(this, BlockerService::class.java).setAction(BlockerService.ACTION_START)
            )
            Toast.makeText(
                this,
                "Top band blocked (y 0–$DAMAGED_BAND_BOTTOM_PX) — blocking ON",
                Toast.LENGTH_LONG
            ).show()
        } else {
            Toast.makeText(
                this,
                "Top band saved — grant overlay permission, then Start blocking",
                Toast.LENGTH_LONG
            ).show()
        }
        refreshSoon()
    }

    private fun maybeAutoStart() {
        if (BlockerService.RUNNING) return
        if (!Settings.canDrawOverlays(this)) return
        if (MaskStore.load(this).isEmpty()) return
        startForegroundService(
            Intent(this, BlockerService::class.java).setAction(BlockerService.ACTION_START)
        )
        refreshSoon()
    }

    private fun addButton(parent: LinearLayout, label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 17f
        b.minHeight = dp(56)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(10)
        parent.addView(b, lp)
        return b
    }

    override fun onResume() {
        super.onResume()
        // Rebuild the current menu so permission/label/running state re-evaluate.
        showMenu(screen)
        maybeShowOnboarding()
    }

    // ------------------------------------------------------------ first-run onboarding

    private fun maybeShowOnboarding() {
        val needed = MaskStore.load(this).isEmpty() && !BlockerService.RUNNING && !onboardSkipped
        if (needed && onboard == null) {
            val v = OnboardView(this)
            rootLayout.addView(
                v,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            )
            onboard = v
        } else if (!needed && onboard != null) {
            rootLayout.removeView(onboard)
            onboard = null
        }
    }

    private fun startAutoSetup() {
        stopService(Intent(this, BlockerService::class.java))
        startActivity(
            Intent(this, CalibrateActivity::class.java)
                .putExtra(CalibrateActivity.EXTRA_AUTO, true)
        )
    }

    /**
     * First-run intent prompt: loosely, what is the user dealing with? Routes to
     * the dead-zone mapper (draw where it works) or the ghost auto-test. Reached
     * only through the onboarding's human-tap gate, so ghost touches can't trip it.
     */
    private fun promptFirstRunIntent() {
        onboardSkipped = true
        onboard?.let { rootLayout.removeView(it); onboard = null }
        AlertDialog.Builder(this)
            .setTitle("Ghost-TouchBlocker")
            .setMessage("What's going on with your screen?")
            .setPositiveButton("Map dead zones") { d, _ ->
                d.dismiss()
                stopService(Intent(this, BlockerService::class.java))
                startActivity(Intent(this, DeadZoneActivity::class.java))
            }
            .setNeutralButton("Bust ghost touches") { d, _ ->
                d.dismiss()
                startAutoSetup()
            }
            .setNegativeButton("Later") { d, _ -> d.dismiss() }
            .show()
    }

    /**
     * Full-screen guidance shown while no active mask exists: everything is
     * visually masked except one randomly placed 200 px "safe zone". A single
     * human-style tap-and-release inside it (40-600 ms, minimal travel — the
     * band this panel's measured ghosts almost never occupy) launches the auto
     * test with auto-apply. Relaunching the app rolls a new safe zone; holding
     * the safe zone skips setup for this session.
     */
    private inner class OnboardView(context: Context) : View(context) {

        private val holeR = 100f
        private var holeX = 0f
        private var holeY = 0f
        private var placed = false

        private var downT = 0L
        private var downX = 0f
        private var downY = 0f
        private var tracking = false

        private val scrimPaint = Paint().apply {
            color = Color.argb(242, 12, 12, 16)
            style = Paint.Style.FILL
        }
        private val ringPaint = Paint().apply {
            color = Color.argb(230, 90, 200, 120)
            style = Paint.Style.STROKE
            strokeWidth = 5f
            isAntiAlias = true
        }
        private val titlePaint = Paint().apply {
            color = Color.WHITE
            textSize = 54f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
            isAntiAlias = true
        }
        private val bodyPaint = Paint().apply {
            color = Color.rgb(205, 205, 212)
            textSize = 38f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        private val smallPaint = Paint().apply {
            color = Color.rgb(140, 140, 150)
            textSize = 30f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        private fun place(w: Int, h: Int) {
            holeX = (140 + kotlin.random.Random.nextInt(w - 280)).toFloat()
            holeY = (280 + kotlin.random.Random.nextInt(h - 560)).toFloat()
            placed = true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (!placed && width > 0 && height > 0) place(width, height)

            val scrim = Path()
            scrim.addRect(0f, 0f, width.toFloat(), height.toFloat(), Path.Direction.CW)
            val hole = Path()
            hole.addCircle(holeX, holeY, holeR, Path.Direction.CW)
            scrim.op(hole, Path.Op.DIFFERENCE)
            canvas.drawPath(scrim, scrimPaint)
            canvas.drawCircle(holeX, holeY, holeR, ringPaint)
            canvas.drawText("safe zone", holeX, holeY + holeR + 48f, smallPaint)

            val cx = width / 2f
            // Keep the text block away from wherever the hole landed.
            val ty = if (holeY < height / 2f) height * 0.68f else height * 0.16f
            canvas.drawText("No active mask detected", cx, ty, titlePaint)
            canvas.drawText("Set up ghost-busting or dead-zone mapping.", cx, ty + 70f, bodyPaint)
            canvas.drawText("Tap the safe zone once to choose,", cx, ty + 125f, bodyPaint)
            canvas.drawText("or relaunch the app for a new safe zone.", cx, ty + 180f, bodyPaint)
            canvas.drawText("(hold the safe zone to skip setup)", cx, ty + 245f, smallPaint)
        }

        private fun inHole(x: Float, y: Float): Boolean {
            val dx = x - holeX
            val dy = y - holeY
            return dx * dx + dy * dy <= holeR * holeR
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    tracking = inHole(event.x, event.y)
                    if (tracking) {
                        downT = SystemClock.uptimeMillis()
                        downX = event.x
                        downY = event.y
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (tracking) {
                        tracking = false
                        val dur = SystemClock.uptimeMillis() - downT
                        val dx = event.x - downX
                        val dy = event.y - downY
                        val still = dx * dx + dy * dy < 30f * 30f
                        if (still && inHole(event.x, event.y)) {
                            if (dur in 40..600) {
                                // Distinctly human: long enough to not be a ghost blip,
                                // short enough to not be a hold. Ask which concern first.
                                promptFirstRunIntent()
                            } else if (dur >= 900) {
                                onboardSkipped = true
                                maybeShowOnboarding()
                            }
                        }
                    }
                }
                MotionEvent.ACTION_CANCEL -> tracking = false
            }
            return true // everything outside the safe zone is swallowed
        }
    }

    /** The service flips its state a beat after we ask; poll a few times so the label settles. */
    private fun refreshSoon() {
        for (delay in longArrayOf(150L, 400L, 800L, 1600L)) {
            status.postDelayed({ refresh() }, delay)
        }
    }

    private fun refresh() {
        val overlayOk = Settings.canDrawOverlays(this)
        val zoneCount = MaskStore.load(this).size
        val running = BlockerService.RUNNING

        startStopButton?.text = if (running) "Stop blocking" else "Start blocking"

        val sb = StringBuilder()
        sb.append(if (overlayOk) "Overlay permission: granted" else "Overlay permission: NOT granted")
        sb.append("\n")
        sb.append(
            when (zoneCount) {
                0 -> "Mask: none saved yet"
                1 -> "Mask: 1 rectangle saved"
                else -> "Mask: $zoneCount rectangles saved"
            }
        )
        sb.append("\n")
        sb.append(if (running) "Blocking: ACTIVE" else "Blocking: off")
        status.text = sb.toString()
    }
}
