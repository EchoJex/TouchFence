package dev.solo.touchfence

import android.app.Application
import android.content.Intent
import android.os.Process
import android.util.Log
import kotlin.system.exitProcess

/**
 * Installs a last-resort crash handler. If anything in the app throws an
 * uncaught exception, a separate-process CrashActivity opens showing the full
 * stack trace with a Copy button — so crashes can be diagnosed on the phone
 * itself, no adb or computer required.
 */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try {
                val i = Intent(this, CrashActivity::class.java)
                i.putExtra("trace", Log.getStackTraceString(e))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                startActivity(i)
            } catch (inner: Throwable) {
                // Nothing more we can do; fall through to process death.
            }
            Process.killProcess(Process.myPid())
            exitProcess(10)
        }
    }
}
