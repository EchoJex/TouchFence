package dev.solo.touchfence

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.provider.Settings
import android.view.KeyEvent
import android.widget.Toast
import kotlin.math.abs

/**
 * Panic apply: pressing volume-up and volume-down together (within [CHORD_MS])
 * from any Ghost-TouchBlocker screen applies the current mask — and if none is saved,
 * recalls the most recently active mask and applies that instead.
 *
 * Single volume presses are left alone so normal volume control still works.
 * Android only delivers key events to a foregrounded activity, so the chord
 * works anywhere inside the app.
 */
object QuickApply {

    private const val CHORD_MS = 400L

    private var upAt = 0L
    private var downAt = 0L

    /** Call from Activity.onKeyDown. Returns true only when the chord fires. */
    fun onKey(context: Context, keyCode: Int): Boolean {
        val now = SystemClock.uptimeMillis()
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> upAt = now
            KeyEvent.KEYCODE_VOLUME_DOWN -> downAt = now
            else -> return false
        }
        if (upAt != 0L && downAt != 0L && abs(upAt - downAt) <= CHORD_MS) {
            upAt = 0L
            downAt = 0L
            apply(context)
            return true
        }
        return false
    }

    fun apply(context: Context) {
        var rects = MaskStore.load(context)
        var recalled = false
        if (rects.isEmpty()) {
            recalled = MaskStore.recallLast(context)
            rects = MaskStore.load(context)
        }
        when {
            rects.isEmpty() ->
                Toast.makeText(context, "No mask available to apply", Toast.LENGTH_SHORT).show()
            !Settings.canDrawOverlays(context) ->
                Toast.makeText(context, "Grant overlay permission first", Toast.LENGTH_SHORT).show()
            else -> {
                context.startForegroundService(
                    Intent(context, BlockerService::class.java)
                        .setAction(BlockerService.ACTION_START)
                )
                val msg = if (recalled) {
                    "Recalled last mask \u2014 blocking ON (${rects.size} zones)"
                } else {
                    "Mask applied \u2014 blocking ON (${rects.size} zones)"
                }
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }
}
