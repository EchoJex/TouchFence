package dev.solo.touchfence

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Auto-detect mode, launched from inside the mask editor. Hands off the phone
 * for [TEST_SECONDS]: every touch the digitizer reports on its own is a ghost.
 * Each contact is logged at full input resolution — exact raw coordinates plus
 * the digitizer's own reported contact size (touchMajor) — and shown live.
 *
 * When time is up, a results list shows every ghost with its duration, size,
 * and position. "Add to mask" turns each ghost into a stroke exactly twice the
 * detected contact size and merges it into the editor's draft — additively, so
 * repeated runs stack their findings instead of starting fresh.
 *
 * Volume keys or Back cancel a running test (touching the screen to cancel
 * would defeat the test).
 */
class CalibrateActivity : Activity() {

    companion object {
        /** How long the hands-off logging phase runs. */
        const val TEST_SECONDS = 60

        /** Pause after tapping Start so your own finger isn't logged. */
        const val GRACE_MS = 2000L

        /** The digitizer's claimed contact size gets clamped to this — damaged
         *  panels routinely report absurdly large ghost blobs. */
        const val DETECT_CAP_PX = 48f

        /** Small fixed expansion from detected point to mask point. */
        const val PAD_PX = 12f

        /** Floor so the rasterizer can't miss a stroke that claimed zero size. */
        const val MIN_SUGGEST_PX = 16f

        /** Safety cap on distinct ghost contacts kept. */
        const val MAX_TRACES = 250

        /** Minimum spacing between recorded points within one contact. */
        const val MIN_POINT_GAP_PX = 3f
    }

    private enum class State { IDLE, GRACE, RECORDING, RESULTS }

    /** One ghost contact: its trace, timing, and the largest contact size seen. */
    private class Ghost(val stroke: Stroke, val startMs: Long) {
        var endMs: Long = startMs
        var maxMajor: Float = 0f
        val durationMs: Long get() = endMs - startMs
    }

    private var state = State.IDLE
    private var phaseStart = 0L

    private val activeGhosts = HashMap<Int, Ghost>()
    private val doneGhosts = mutableListOf<Ghost>()
    private var eventCount = 0

    private lateinit var testView: TestView
    private lateinit var panel: LinearLayout
    private lateinit var infoText: TextView
    private lateinit var resultsScroll: ScrollView
    private lateinit var resultsText: TextView
    private lateinit var idleRow: LinearLayout
    private lateinit var resultsRow: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            when (state) {
                State.GRACE -> {
                    if (SystemClock.elapsedRealtime() - phaseStart >= GRACE_MS) {
                        state = State.RECORDING
                        phaseStart = SystemClock.elapsedRealtime()
                    }
                    testView.invalidate()
                    handler.postDelayed(this, 100L)
                }
                State.RECORDING -> {
                    val elapsed = SystemClock.elapsedRealtime() - phaseStart
                    if (elapsed >= TEST_SECONDS * 1000L) {
                        finishTest()
                    } else {
                        testView.invalidate()
                        handler.postDelayed(this, 100L)
                    }
                }
                else -> {
                    // Ticker stops in IDLE and RESULTS.
                }
            }
        }
    }

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Blocking overlays would eat the very ghost touches we're listening for.
        stopService(Intent(this, BlockerService::class.java))

        val root = FrameLayout(this)
        testView = TestView(this)
        root.addView(
            testView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(16), dp(12), dp(16), dp(28))
        panel.setBackgroundColor(Color.argb(195, 16, 16, 20))

        infoText = TextView(this)
        infoText.text = "Set the phone down and touch nothing for $TEST_SECONDS seconds. " +
                "Ghost touches are logged at full resolution with their size and " +
                "duration. Volume keys or Back cancel a running test."
        infoText.setTextColor(Color.rgb(200, 200, 208))
        infoText.textSize = 14f
        infoText.setPadding(0, 0, 0, dp(8))
        panel.addView(infoText)

        resultsText = TextView(this)
        resultsText.setTextColor(Color.rgb(230, 230, 236))
        resultsText.textSize = 12f
        resultsText.typeface = Typeface.MONOSPACE
        resultsScroll = ScrollView(this)
        resultsScroll.addView(resultsText)
        val scrollLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(200)
        )
        scrollLp.bottomMargin = dp(8)
        resultsScroll.visibility = View.GONE
        panel.addView(resultsScroll, scrollLp)

        idleRow = LinearLayout(this)
        idleRow.orientation = LinearLayout.HORIZONTAL
        addBarButton(idleRow, "Start $TEST_SECONDS-second test") { startTest() }
        addBarButton(idleRow, "Close") { finish() }
        panel.addView(idleRow)

        resultsRow = LinearLayout(this)
        resultsRow.orientation = LinearLayout.HORIZONTAL
        addBarButton(resultsRow, "Add to mask") { addToMask() }
        addBarButton(resultsRow, "Discard") { toIdle("Results discarded. Test again when ready.") }
        addBarButton(resultsRow, "Test again") { startTest() }
        resultsRow.visibility = View.GONE
        panel.addView(resultsRow)

        val panelLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        panelLp.gravity = Gravity.BOTTOM
        root.addView(panel, panelLp)

        setContentView(root)
        goEdgeToEdge()
    }

    private fun addBarButton(parent: LinearLayout, label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 15f
        b.minHeight = dp(52)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.leftMargin = dp(4)
        lp.rightMargin = dp(4)
        parent.addView(b, lp)
        return b
    }

    private fun goEdgeToEdge() {
        try {
            window.setDecorFitsSystemWindows(false)
        } catch (t: Throwable) {
            // Cosmetic only; ignore.
        }
        try {
            val attrs = window.attributes
            attrs.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            window.attributes = attrs
        } catch (t: Throwable) {
            // Cosmetic only; ignore.
        }
        try {
            val controller = window.insetsController
            if (controller != null) {
                controller.hide(WindowInsets.Type.systemBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } catch (t: Throwable) {
            // Cosmetic only; ignore.
        }
    }

    // ------------------------------------------------------------------ phases

    private fun startTest() {
        activeGhosts.clear()
        doneGhosts.clear()
        eventCount = 0
        state = State.GRACE
        phaseStart = SystemClock.elapsedRealtime()
        panel.visibility = View.GONE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    private fun toIdle(message: String) {
        state = State.IDLE
        handler.removeCallbacks(ticker)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        panel.visibility = View.VISIBLE
        resultsScroll.visibility = View.GONE
        resultsRow.visibility = View.GONE
        idleRow.visibility = View.VISIBLE
        infoText.text = message
        testView.invalidate()
    }

    private fun finishTest() {
        handler.removeCallbacks(ticker)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Close out any contacts still "held down" by the ghost.
        val now = SystemClock.uptimeMillis()
        for (g in activeGhosts.values) {
            g.endMs = now
            finalizeGhost(g)
        }
        activeGhosts.clear()

        if (doneGhosts.isEmpty()) {
            toIdle("No ghost touches detected in $TEST_SECONDS seconds. " +
                    "Run it again, or draw the mask by hand.")
            return
        }

        state = State.RESULTS
        panel.visibility = View.VISIBLE
        idleRow.visibility = View.GONE
        resultsRow.visibility = View.VISIBLE
        resultsScroll.visibility = View.VISIBLE
        infoText.text = "Red dots show what was logged. Review, then add to the mask."
        resultsText.text = buildReport()
        resultsScroll.scrollTo(0, 0)
        testView.invalidate()
    }

    private fun buildReport(): String {
        val durations = doneGhosts.map { it.durationMs }.sorted()
        val median = if (durations.size % 2 == 1) {
            durations[durations.size / 2]
        } else {
            (durations[durations.size / 2 - 1] + durations[durations.size / 2]) / 2
        }
        val sb = StringBuilder()
        sb.append("${doneGhosts.size} ghosts, $eventCount raw events\n")
        sb.append("duration ms  min ${durations.first()}")
        sb.append("  median $median  max ${durations.last()}\n\n")
        for ((i, g) in doneGhosts.withIndex()) {
            val x = g.stroke.pts[0].roundToInt()
            val y = g.stroke.pts[1].roundToInt()
            sb.append("#${i + 1}")
            sb.append("  ${g.durationMs} ms")
            sb.append("  ~${g.maxMajor.roundToInt()} px \u2192 ${g.stroke.width.roundToInt()} px")
            sb.append("  ($x, $y)\n")
        }
        return sb.toString()
    }

    private fun addToMask() {
        // Merge with the existing draft. Old strokes get their saved D-pad
        // offset baked into their points, so everything now sits at its true
        // screen position and the shared offset resets to zero.
        val (old, ox, oy) = MaskStore.loadDraft(this)
        if (ox != 0 || oy != 0) {
            for (s in old) {
                var i = 0
                while (i + 1 < s.pts.size) {
                    s.pts[i] = s.pts[i] + ox
                    s.pts[i + 1] = s.pts[i + 1] + oy
                    i += 2
                }
                s.rebuildPath()
            }
        }
        val combined = mutableListOf<Stroke>()
        combined.addAll(old)
        for (g in doneGhosts) combined.add(g.stroke)
        MaskStore.saveDraft(this, combined, 0, 0)

        Toast.makeText(
            this,
            "${doneGhosts.size} ghost strokes added to the mask",
            Toast.LENGTH_LONG
        ).show()
        finish() // back to the editor, which reloads the merged draft
    }

    /** Sets the final stroke width (clamped detected size + pad) and pads lone points into dots. */
    private fun finalizeGhost(g: Ghost) {
        g.stroke.width = max(min(g.maxMajor, DETECT_CAP_PX) + PAD_PX, MIN_SUGGEST_PX)
        if (g.stroke.pts.size == 2) {
            g.stroke.add(g.stroke.pts[0] + 1f, g.stroke.pts[1])
        }
        if (g.stroke.pts.size >= 2) doneGhosts.add(g)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP)
            && (state == State.GRACE || state == State.RECORDING)
        ) {
            toIdle("Test cancelled. Start again when ready.")
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ the test surface

    private inner class TestView(context: Context) : View(context) {

        private val dotPaint = Paint().apply {
            color = Color.argb(220, 220, 30, 30)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        private val bigPaint = Paint().apply {
            color = Color.rgb(55, 55, 65)
            textSize = 140f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        private val textPaint = Paint().apply {
            color = Color.rgb(55, 55, 65)
            textSize = 42f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        init {
            // White: dead pixels stand out, and it doubles as a clean test field.
            setBackgroundColor(Color.WHITE)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (state != State.RECORDING) return true
            eventCount++
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    val idx = event.actionIndex
                    val id = event.getPointerId(idx)
                    if (activeGhosts.size + doneGhosts.size < MAX_TRACES) {
                        val s = Stroke(MIN_SUGGEST_PX)
                        s.add(event.getRawX(idx), event.getRawY(idx))
                        val g = Ghost(s, event.eventTime)
                        g.maxMajor = event.getTouchMajor(idx)
                        activeGhosts[id] = g
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    for (i in 0 until event.pointerCount) {
                        val id = event.getPointerId(i)
                        val g = activeGhosts[id] ?: continue
                        g.maxMajor = max(g.maxMajor, event.getTouchMajor(i))
                        g.endMs = event.eventTime
                        val x = event.getRawX(i)
                        val y = event.getRawY(i)
                        val gx = x - g.stroke.lastX()
                        val gy = y - g.stroke.lastY()
                        if (gx * gx + gy * gy >= MIN_POINT_GAP_PX * MIN_POINT_GAP_PX) {
                            g.stroke.add(x, y)
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                    val id = event.getPointerId(event.actionIndex)
                    val g = activeGhosts.remove(id)
                    if (g != null) {
                        g.endMs = event.eventTime
                        finalizeGhost(g)
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    for (g in activeGhosts.values) {
                        g.endMs = event.eventTime
                        finalizeGhost(g)
                    }
                    activeGhosts.clear()
                }
            }
            invalidate()
            return true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f

            for (g in doneGhosts) drawTrace(canvas, g.stroke)
            for (g in activeGhosts.values) drawTrace(canvas, g.stroke)

            when (state) {
                State.IDLE -> {
                    canvas.drawText("Ghost touch test", cx, cy - 40f, textPaint)
                    canvas.drawText("Tap Start, then hands off", cx, cy + 30f, textPaint)
                }
                State.GRACE -> {
                    canvas.drawText("Hands off\u2026", cx, cy, bigPaint)
                }
                State.RECORDING -> {
                    val elapsed = SystemClock.elapsedRealtime() - phaseStart
                    val remaining = TEST_SECONDS - (elapsed / 1000L).toInt()
                    canvas.drawText("$remaining", cx, cy, bigPaint)
                    canvas.drawText("touch nothing", cx, cy + 90f, textPaint)
                    canvas.drawText(
                        "ghosts logged: ${doneGhosts.size + activeGhosts.size}",
                        cx, cy + 160f, textPaint
                    )
                }
                State.RESULTS -> {
                    canvas.drawText("Test done \u2014 results below", cx, cy, textPaint)
                }
            }
        }

        private fun drawTrace(canvas: Canvas, s: Stroke) {
            var i = 0
            while (i + 1 < s.pts.size) {
                canvas.drawCircle(s.pts[i], s.pts[i + 1], 6f, dotPaint)
                i += 2
            }
        }
    }
}
