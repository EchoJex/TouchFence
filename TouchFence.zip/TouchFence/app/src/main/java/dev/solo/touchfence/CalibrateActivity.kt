package dev.solo.touchfence

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Auto-detect mode. The phone sits untouched on a white test screen for
 * [TEST_SECONDS] while every touch the digitizer reports — which, hands off,
 * can only be a ghost — is logged at full input resolution and shown live as
 * red dots. Each ghost contact becomes a padded brush stroke at its true
 * screen position, merged into the mask draft, and the editor opens on the
 * result for review.
 *
 * Volume keys or Back cancel a running test (the screen itself can't be used
 * to cancel, since touching it is exactly what the test must not see).
 */
class CalibrateActivity : Activity() {

    companion object {
        /** How long the hands-off logging phase runs. */
        const val TEST_SECONDS = 60

        /** Pause after tapping Start so your own finger isn't logged. */
        const val GRACE_MS = 2000L

        /** Brush width given to each suggested stroke — padding around the ghost line. */
        const val SUGGEST_BRUSH_PX = 90f

        /** Safety cap on distinct ghost contacts kept. */
        const val MAX_TRACES = 250

        /** Minimum spacing between recorded points within one contact. */
        const val MIN_POINT_GAP_PX = 3f
    }

    private enum class State { IDLE, GRACE, RECORDING }

    private var state = State.IDLE
    private var phaseStart = 0L

    private val activeTraces = HashMap<Int, Stroke>()
    private val doneTraces = mutableListOf<Stroke>()
    private var eventCount = 0

    private lateinit var testView: TestView
    private lateinit var panel: LinearLayout
    private lateinit var infoText: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            when (state) {
                State.GRACE -> {
                    if (SystemClock.elapsedRealtime() - phaseStart >= GRACE_MS) {
                        state = State.RECORDING
                        phaseStart = SystemClock.elapsedRealtime()
                    }
                    testView.invalidate()
                    handler.postDelayed(this, 100L)
                }
                State.RECORDING -> {
                    val elapsed = SystemClock.elapsedRealtime() - phaseStart
                    if (elapsed >= TEST_SECONDS * 1000L) {
                        finishTest()
                    } else {
                        testView.invalidate()
                        handler.postDelayed(this, 100L)
                    }
                }
                State.IDLE -> {
                    // Ticker stops.
                }
            }
        }
    }

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Blocking overlays would eat the very ghost touches we're listening for.
        stopService(Intent(this, BlockerService::class.java))

        val root = FrameLayout(this)
        testView = TestView(this)
        root.addView(
            testView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(16), dp(12), dp(16), dp(28))
        panel.setBackgroundColor(Color.argb(195, 16, 16, 20))

        infoText = TextView(this)
        infoText.text = "Set the phone down and touch nothing for $TEST_SECONDS seconds. " +
                "Every touch the screen reports on its own gets logged and turned into " +
                "a suggested mask. Volume keys or Back cancel a running test."
        infoText.setTextColor(Color.rgb(200, 200, 208))
        infoText.textSize = 14f
        infoText.setPadding(0, 0, 0, dp(8))
        panel.addView(infoText)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        addBarButton(row, "Start $TEST_SECONDS-second test") { startTest() }
        addBarButton(row, "Close") { finish() }
        panel.addView(row)

        val panelLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        panelLp.gravity = Gravity.BOTTOM
        root.addView(panel, panelLp)

        setContentView(root)
        goEdgeToEdge()
    }

    private fun addBarButton(parent: LinearLayout, label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 16f
        b.minHeight = dp(52)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.leftMargin = dp(4)
        lp.rightMargin = dp(4)
        parent.addView(b, lp)
        return b
    }

    private fun goEdgeToEdge() {
        try {
            window.setDecorFitsSystemWindows(false)
        } catch (t: Throwable) {
            // Cosmetic only; ignore.
        }
        try {
            val attrs = window.attributes
            attrs.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            window.attributes = attrs
        } catch (t: Throwable) {
            // Cosmetic only; ignore.
        }
        try {
            val controller = window.insetsController
            if (controller != null) {
                controller.hide(WindowInsets.Type.systemBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } catch (t: Throwable) {
            // Cosmetic only; ignore.
        }
    }

    // ------------------------------------------------------------------ phases

    private fun startTest() {
        activeTraces.clear()
        doneTraces.clear()
        eventCount = 0
        state = State.GRACE
        phaseStart = SystemClock.elapsedRealtime()
        panel.visibility = View.GONE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    private fun cancelTest() {
        state = State.IDLE
        handler.removeCallbacks(ticker)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        panel.visibility = View.VISIBLE
        infoText.text = "Test cancelled. Start again when ready."
        testView.invalidate()
    }

    private fun finishTest() {
        state = State.IDLE
        handler.removeCallbacks(ticker)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        // Close out any contacts still "held down" by the ghost.
        for (s in activeTraces.values) finalizeTrace(s)
        activeTraces.clear()

        if (doneTraces.isEmpty()) {
            panel.visibility = View.VISIBLE
            infoText.text = "No ghost touches detected in $TEST_SECONDS seconds. " +
                    "Run it again, or draw the mask by hand."
            testView.invalidate()
            return
        }

        // Merge with the existing draft. Old strokes get their saved D-pad
        // offset baked into their points, so everything now sits at its true
        // screen position and the shared offset resets to zero.
        val (old, ox, oy) = MaskStore.loadDraft(this)
        if (ox != 0 || oy != 0) {
            for (s in old) {
                var i = 0
                while (i + 1 < s.pts.size) {
                    s.pts[i] = s.pts[i] + ox
                    s.pts[i + 1] = s.pts[i + 1] + oy
                    i += 2
                }
                s.rebuildPath()
            }
        }
        val combined = mutableListOf<Stroke>()
        combined.addAll(old)
        combined.addAll(doneTraces)
        MaskStore.saveDraft(this, combined, 0, 0)

        Toast.makeText(
            this,
            "Logged $eventCount ghost events \u2192 ${doneTraces.size} strokes suggested",
            Toast.LENGTH_LONG
        ).show()
        startActivity(Intent(this, DrawMaskActivity::class.java))
        finish()
    }

    /** Ghosts often report a single point; pad it so it renders and rasterizes as a dot. */
    private fun finalizeTrace(s: Stroke) {
        if (s.pts.size == 2) {
            s.add(s.pts[0] + 1f, s.pts[1])
        }
        if (s.pts.size >= 2) doneTraces.add(s)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP)
            && state != State.IDLE
        ) {
            cancelTest()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        super.onDestroy()
    }

    // ------------------------------------------------------------------ the test surface

    private inner class TestView(context: Context) : View(context) {

        private val dotPaint = Paint().apply {
            color = Color.argb(220, 220, 30, 30)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        private val bigPaint = Paint().apply {
            color = Color.rgb(55, 55, 65)
            textSize = 140f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        private val textPaint = Paint().apply {
            color = Color.rgb(55, 55, 65)
            textSize = 42f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        init {
            // White: dead pixels stand out, and it doubles as a clean test field.
            setBackgroundColor(Color.WHITE)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (state != State.RECORDING) return true
            eventCount++
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    val idx = event.actionIndex
                    val id = event.getPointerId(idx)
                    if (activeTraces.size + doneTraces.size < MAX_TRACES) {
                        val s = Stroke(SUGGEST_BRUSH_PX)
                        s.add(event.getRawX(idx), event.getRawY(idx))
                        activeTraces[id] = s
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    for (i in 0 until event.pointerCount) {
                        val id = event.getPointerId(i)
                        val s = activeTraces[id] ?: continue
                        val x = event.getRawX(i)
                        val y = event.getRawY(i)
                        val gx = x - s.lastX()
                        val gy = y - s.lastY()
                        if (gx * gx + gy * gy >= MIN_POINT_GAP_PX * MIN_POINT_GAP_PX) {
                            s.add(x, y)
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                    val id = event.getPointerId(event.actionIndex)
                    val s = activeTraces.remove(id)
                    if (s != null) finalizeTrace(s)
                }
                MotionEvent.ACTION_CANCEL -> {
                    for (s in activeTraces.values) finalizeTrace(s)
                    activeTraces.clear()
                }
            }
            invalidate()
            return true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f

            for (s in doneTraces) drawTrace(canvas, s)
            for (s in activeTraces.values) drawTrace(canvas, s)

            when (state) {
                State.IDLE -> {
                    canvas.drawText("Ghost touch test", cx, cy - 40f, textPaint)
                    canvas.drawText("Tap Start, then hands off", cx, cy + 30f, textPaint)
                }
                State.GRACE -> {
                    canvas.drawText("Hands off\u2026", cx, cy, bigPaint)
                }
                State.RECORDING -> {
                    val elapsed = SystemClock.elapsedRealtime() - phaseStart
                    val remaining = TEST_SECONDS - (elapsed / 1000L).toInt()
                    canvas.drawText("$remaining", cx, cy, bigPaint)
                    canvas.drawText("touch nothing", cx, cy + 90f, textPaint)
                    canvas.drawText(
                        "ghosts logged: ${doneTraces.size + activeTraces.size}",
                        cx, cy + 160f, textPaint
                    )
                }
            }
        }

        private fun drawTrace(canvas: Canvas, s: Stroke) {
            var i = 0
            while (i + 1 < s.pts.size) {
                canvas.drawCircle(s.pts[i], s.pts[i + 1], 8f, dotPaint)
                i += 2
            }
        }
    }
}
