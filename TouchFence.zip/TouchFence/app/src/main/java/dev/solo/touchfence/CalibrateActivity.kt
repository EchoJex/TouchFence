package dev.solo.touchfence

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

/**
 * Auto-detect mode, launched from inside the mask editor.
 *
 * Model: a ghost is a point, not a gesture. Every coordinate sample the
 * digitizer reports while nobody is touching becomes one independent mask dot
 * at its exact position — samples are never connected into swipes, shapes are
 * never filled, and the panel's claimed contact sizes are ignored entirely.
 * Contact lifecycles (down..up) are kept only as timing envelopes so durations
 * can be measured at the finest clock the OS offers.
 *
 * Runs ACCUMULATE: "Test again" adds to what previous runs found. Only
 * Discard clears the pot; Add to mask commits everything gathered — merged
 * additively into whatever is already drawn in the editor.
 *
 * Volume keys or Back cancel a running test (touching the screen to cancel
 * would defeat the test). Cancelling keeps what was gathered so far.
 */
class CalibrateActivity : Activity() {

    companion object {
        /** Launch extra: start the test immediately and auto-apply the result. */
        const val EXTRA_AUTO = "auto"

        /** How long each hands-off logging run lasts. */
        const val TEST_SECONDS = 35

        /** Pause after tapping Start so your own finger isn't logged. */
        const val GRACE_MS = 2000L

        /** Width of the independent mask dot placed at each sample. */
        const val MASK_DOT_PX = 8f

        /** Samples landing within the same cell of this size dedupe to one dot. */
        const val DOT_MERGE_PX = 4

        /** Safety caps. */
        const val MAX_CONTACTS = 5000
        const val MAX_DOTS = 10000

        /** Pressure mute ("safe") zones: each of the 5 spots holds for
         *  [MUTE_EACH_MS] back-to-back, then the rest of the run has no safe
         *  zone at all (open detection to catch any remaining evasive ghosts).
         *  With TEST_SECONDS = 35 and 5 spots × 5 s that leaves a 10 s open
         *  tail. Contacts starting inside a live safe zone are excluded;
         *  detection continues everywhere else. */
        const val MUTE_EACH_MS = 5_000L
        const val MUTE_R = 140f
    }

    private enum class State { IDLE, GRACE, RECORDING, RESULTS }

    /** One raw coordinate sample within a contact. */
    private class Sample(val tUs: Long, val x: Float, val y: Float)

    /** Timing envelope of one contact lifecycle. Not a shape, not a gesture. */
    private class Ghost(val x: Float, val y: Float, val startNs: Long) {
        var endNs: Long = startNs
        val sampleList = ArrayList<Sample>()
        val durationUs: Long get() = (endNs - startNs) / 1_000L
    }

    /** Nanosecond event time where the OS provides it (public on API 34+),
     *  millisecond-derived fallback otherwise. Class.forName keeps this safe
     *  to compile and run on any version. */
    private val nanosMethod = try {
        Class.forName("android.view.MotionEvent").getMethod("getEventTimeNanos")
    } catch (t: Throwable) {
        null
    }

    private fun eventNs(e: MotionEvent): Long = try {
        (nanosMethod?.invoke(e) as? Long) ?: (e.eventTime * 1_000_000L)
    } catch (t: Throwable) {
        e.eventTime * 1_000_000L
    }

    private var state = State.IDLE
    private var phaseStart = 0L
    private var runCount = 0
    private var runStartNs = 0L
    private var loggedContacts = 0
    private var autoMode = false
    private val sessionId = System.currentTimeMillis()

    private val activeGhosts = HashMap<Int, Ghost>()
    private val doneGhosts = mutableListOf<Ghost>()
    private val dotStrokes = mutableListOf<Stroke>()
    private val occupiedCells = HashSet<Long>()
    private val mutedIds = HashSet<Int>()
    private var eventCount = 0
    private var sampleCount = 0
    private var wakeLock: PowerManager.WakeLock? = null

    private lateinit var testView: TestView
    private lateinit var panel: LinearLayout
    private lateinit var infoText: TextView
    private lateinit var resultsScroll: ScrollView
    private lateinit var resultsText: TextView
    private lateinit var idleRow: LinearLayout
    private lateinit var resultsRow: LinearLayout
    private lateinit var resultsRow2: LinearLayout

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            when (state) {
                State.GRACE -> {
                    if (SystemClock.elapsedRealtime() - phaseStart >= GRACE_MS) {
                        state = State.RECORDING
                        phaseStart = SystemClock.elapsedRealtime()
                        runStartNs = SystemClock.uptimeMillis() * 1_000_000L
                    }
                    testView.invalidate()
                    handler.postDelayed(this, 100L)
                }
                State.RECORDING -> {
                    val elapsed = SystemClock.elapsedRealtime() - phaseStart
                    if (elapsed >= TEST_SECONDS * 1000L) {
                        finishTest()
                    } else {
                        testView.invalidate()
                        handler.postDelayed(this, 100L)
                    }
                }
                else -> {
                    // Ticker stops in IDLE and RESULTS.
                }
            }
        }
    }

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Blocking overlays would eat the very ghost touches we're listening for.
        stopService(Intent(this, BlockerService::class.java))

        val root = FrameLayout(this)
        testView = TestView(this)
        root.addView(
            testView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(16), dp(12), dp(16), dp(28))
        panel.setBackgroundColor(Color.argb(195, 16, 16, 20))

        infoText = TextView(this)
        infoText.text = "Set the phone down and touch nothing for $TEST_SECONDS seconds. " +
                "Every point the screen reports on its own becomes one mask dot at its " +
                "exact position. Repeat runs add up until you Discard or Add to mask. " +
                "Volume keys or Back cancel a running test.\n" +
                "Tip: the app can't change touch sensitivity — turn Screen protector " +
                "mode ON (Display settings) for maximum sensitivity, so more ghosts show, before testing."
        infoText.setTextColor(Color.rgb(200, 200, 208))
        infoText.textSize = 14f
        infoText.setPadding(0, 0, 0, dp(8))
        panel.addView(infoText)

        resultsText = TextView(this)
        resultsText.setTextColor(Color.rgb(230, 230, 236))
        resultsText.textSize = 12f
        resultsText.typeface = Typeface.MONOSPACE
        resultsScroll = ScrollView(this)
        resultsScroll.addView(resultsText)
        val scrollLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(200)
        )
        scrollLp.bottomMargin = dp(8)
        resultsScroll.visibility = View.GONE
        panel.addView(resultsScroll, scrollLp)

        idleRow = LinearLayout(this)
        idleRow.orientation = LinearLayout.HORIZONTAL
        addBarButton(idleRow, "Start $TEST_SECONDS-second test") { startTest() }
        addBarButton(idleRow, "Close") { finish() }
        panel.addView(idleRow)

        resultsRow = LinearLayout(this)
        resultsRow.orientation = LinearLayout.HORIZONTAL
        addBarButton(resultsRow, "Add to mask") { addToMask() }
        addBarButton(resultsRow, "Discard") {
            clearGathered()
            toIdle("Results discarded. Test again when ready.")
        }
        addBarButton(resultsRow, "Test again (+)") { startTest() }
        resultsRow.visibility = View.GONE
        panel.addView(resultsRow)

        resultsRow2 = LinearLayout(this)
        resultsRow2.orientation = LinearLayout.HORIZONTAL
        addBarButton(resultsRow2, "Copy data") {
            val export = LogStore.buildExport(this)
            val clipped = if (export.length > 300_000) {
                export.substring(0, 300_000) +
                        "\n# truncated for clipboard \u2014 use Save log for the full file\n"
            } else {
                export
            }
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("TouchFence ghost data", clipped))
            Toast.makeText(this, "Copied \u2014 paste it to your AI", Toast.LENGTH_SHORT).show()
        }
        addBarButton(resultsRow2, "Save log") {
            val name = LogStore.saveToDownloads(this, LogStore.buildExport(this))
            Toast.makeText(
                this,
                if (name != null) "Saved to Downloads as $name" else "Save failed",
                Toast.LENGTH_LONG
            ).show()
        }
        resultsRow2.visibility = View.GONE
        panel.addView(resultsRow2)

        val panelLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        panelLp.gravity = Gravity.BOTTOM
        root.addView(panel, panelLp)

        setContentView(root)
        goEdgeToEdge()

        autoMode = intent.getBooleanExtra(EXTRA_AUTO, false)
        if (autoMode) {
            // Onboarding flow: the human tap already happened; go straight in.
            startTest()
        }
    }

    private fun addBarButton(parent: LinearLayout, label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 15f
        b.minHeight = dp(52)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.leftMargin = dp(4)
        lp.rightMargin = dp(4)
        parent.addView(b, lp)
        return b
    }

    private fun goEdgeToEdge() {
        try {
            window.setDecorFitsSystemWindows(false)
        } catch (t: Throwable) {
            // Cosmetic only; ignore.
        }
        try {
            val attrs = window.attributes
            attrs.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            window.attributes = attrs
        } catch (t: Throwable) {
            // Cosmetic only; ignore.
        }
        try {
            val controller = window.insetsController
            if (controller != null) {
                controller.hide(WindowInsets.Type.systemBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } catch (t: Throwable) {
            // Cosmetic only; ignore.
        }
    }

    // ------------------------------------------------------------------ data

    private fun clearGathered() {
        activeGhosts.clear()
        doneGhosts.clear()
        dotStrokes.clear()
        occupiedCells.clear()
        eventCount = 0
        sampleCount = 0
        runCount = 0
        loggedContacts = 0
    }

    /** Writes rows for contacts gathered since the last append into the persistent log. */
    private fun appendRunLog() {
        if (doneGhosts.size <= loggedContacts) return
        val sb = StringBuilder()
        sb.append("R,").append(sessionId).append(',').append(runCount)
            .append(',').append(System.currentTimeMillis()).append('\n')
        for (idx in loggedContacts until doneGhosts.size) {
            val g = doneGhosts[idx]
            val startUs = ((g.startNs - runStartNs) / 1_000L).coerceAtLeast(0L)
            sb.append("C,").append(runCount).append(',').append(idx + 1).append(',')
                .append(startUs).append(',').append(g.durationUs).append(',')
                .append(g.sampleList.size).append(',')
                .append(g.x.roundToInt()).append(',').append(g.y.roundToInt()).append('\n')
            for (s in g.sampleList) {
                sb.append("S,").append(idx + 1).append(',').append(s.tUs).append(',')
                    .append(s.x).append(',').append(s.y).append('\n')
            }
        }
        if (!LogStore.append(this, sb.toString())) {
            Toast.makeText(this, "Ghost log is full \u2014 export and clear it", Toast.LENGTH_LONG).show()
        }
        loggedContacts = doneGhosts.size
    }

    /** Every sample becomes an independent dot; duplicates within DOT_MERGE_PX dedupe.
     *  The raw timestamped coordinate is retained for the exportable log. */
    private fun recordSample(g: Ghost, tNs: Long, x: Float, y: Float) {
        sampleCount++
        g.sampleList.add(Sample(((tNs - g.startNs) / 1_000L).coerceAtLeast(0L), x, y))
        if (dotStrokes.size >= MAX_DOTS) return
        val qx = (x / DOT_MERGE_PX).toInt().toLong()
        val qy = (y / DOT_MERGE_PX).toInt().toLong()
        val key = (qx shl 32) or (qy and 0xffffffffL)
        if (occupiedCells.add(key)) {
            val dot = Stroke(MASK_DOT_PX)
            dot.add(x, y)
            dot.add(x + 1f, y)
            dotStrokes.add(dot)
        }
    }

    // ------------------------------------------------------------------ phases

    private fun startTest() {
        // Gathered results (contacts + dots) accumulate across runs, but the
        // dedupe grid resets each run so a run re-reports ghosts at cells earlier
        // runs already marked — every run shows its own fresh yield.
        activeGhosts.clear()
        mutedIds.clear()
        occupiedCells.clear()
        runCount++
        state = State.GRACE
        phaseStart = SystemClock.elapsedRealtime()
        panel.visibility = View.GONE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        boostPerformance()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    /** Ask the system for everything: CPU held awake, display at its highest
     *  rate (less input batching latency), sustained-performance clocks, and
     *  the capture (main) thread bumped to urgent-display priority so brief
     *  ghosts aren't missed to scheduling. Every step is best-effort. */
    private fun boostPerformance() {
        try {
            // The capture runs on this (main) thread; give it the highest
            // display-class scheduling priority so it isn't descheduled while a
            // sub-millisecond ghost is being logged.
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY)
        } catch (t: Throwable) {
            // Best effort.
        }
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TouchFence:test")
            wakeLock?.acquire(GRACE_MS + TEST_SECONDS * 1000L + 5000L)
        } catch (t: Throwable) {
            // Best effort.
        }
        try {
            val modes = display?.supportedModes
            if (modes != null && modes.isNotEmpty()) {
                var best = 0f
                for (m in modes) if (m.refreshRate > best) best = m.refreshRate
                val attrs = window.attributes
                attrs.preferredRefreshRate = best
                window.attributes = attrs
            }
        } catch (t: Throwable) {
            // Best effort.
        }
        // Note: sustained-performance mode is intentionally NOT enabled — it
        // caps peak clocks for thermal consistency, but a 35 s burst won't
        // throttle, so we want the SoC free to turbo and catch the briefest ghosts.
    }

    private fun releasePerformance() {
        try {
            Process.setThreadPriority(Process.THREAD_PRIORITY_DEFAULT)
        } catch (t: Throwable) {
            // Best effort.
        }
        try {
            wakeLock?.release()
        } catch (t: Throwable) {
            // Already released.
        }
        wakeLock = null
    }

    private fun toIdle(message: String) {
        state = State.IDLE
        handler.removeCallbacks(ticker)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        releasePerformance()
        panel.visibility = View.VISIBLE
        resultsScroll.visibility = View.GONE
        resultsRow.visibility = View.GONE
        resultsRow2.visibility = View.GONE
        idleRow.visibility = View.VISIBLE
        infoText.text = if (doneGhosts.isNotEmpty() || dotStrokes.isNotEmpty()) {
            message + "\nGathered so far: ${doneGhosts.size} contacts, " +
                    "${dotStrokes.size} dots \u2014 runs keep adding up."
        } else {
            message
        }
        testView.invalidate()
    }

    private fun finishTest() {
        handler.removeCallbacks(ticker)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        releasePerformance()
        mutedIds.clear()

        // Close out any contacts still "held down" by the ghost.
        val nowNs = SystemClock.uptimeMillis() * 1_000_000L
        for (g in activeGhosts.values) {
            g.endNs = nowNs
            doneGhosts.add(g)
        }
        activeGhosts.clear()

        appendRunLog()

        if (doneGhosts.isEmpty()) {
            autoMode = false
            toIdle("No ghost touches detected yet ($runCount run(s)). " +
                    "Run it again, or draw the mask by hand.")
            return
        }

        if (autoMode) {
            mergeIntoDraft()
            Toast.makeText(
                this,
                "${dotStrokes.size} ghost dots found \u2014 applying mask",
                Toast.LENGTH_LONG
            ).show()
            startActivity(
                Intent(this, DrawMaskActivity::class.java)
                    .putExtra(DrawMaskActivity.EXTRA_AUTO_APPLY, true)
            )
            finish()
            return
        }

        state = State.RESULTS
        panel.visibility = View.VISIBLE
        idleRow.visibility = View.GONE
        resultsRow.visibility = View.VISIBLE
        resultsRow2.visibility = View.VISIBLE
        resultsScroll.visibility = View.VISIBLE
        infoText.text = "Red dots show every gathered point. Test again to add more, " +
                "or commit with Add to mask."
        resultsText.text = buildReport()
        resultsScroll.scrollTo(0, 0)
        testView.invalidate()
    }

    private fun buildReport(): String {
        val durations = doneGhosts.map { it.durationUs }.sorted()
        val median = if (durations.size % 2 == 1) {
            durations[durations.size / 2]
        } else {
            (durations[durations.size / 2 - 1] + durations[durations.size / 2]) / 2
        }
        val sb = StringBuilder()
        sb.append("${doneGhosts.size} contacts across $runCount run(s)\n")
        sb.append("$eventCount events, $sampleCount samples, ${dotStrokes.size} mask dots\n")
        sb.append("duration \u00b5s  min ${durations.first()}")
        sb.append("  median $median  max ${durations.last()}\n")
        sb.append("each dot: ${MASK_DOT_PX.roundToInt()} px, independent \u2014 ")
        sb.append("no swipes, no size assumptions\n\n")
        for ((i, g) in doneGhosts.withIndex()) {
            sb.append("#${i + 1}")
            sb.append("  ${g.durationUs} \u00b5s")
            sb.append("  ${g.sampleList.size} pt")
            sb.append("  (${g.x.roundToInt()}, ${g.y.roundToInt()})\n")
        }
        return sb.toString()
    }

    /** Merges gathered dots into the draft, baking any saved D-pad offset to zero. */
    private fun mergeIntoDraft() {
        val (old, ox, oy) = MaskStore.loadDraft(this)
        if (ox != 0 || oy != 0) {
            for (s in old) {
                var i = 0
                while (i + 1 < s.pts.size) {
                    s.pts[i] = s.pts[i] + ox
                    s.pts[i + 1] = s.pts[i + 1] + oy
                    i += 2
                }
                s.rebuildPath()
            }
        }
        val combined = mutableListOf<Stroke>()
        combined.addAll(old)
        combined.addAll(dotStrokes)
        MaskStore.saveDraft(this, combined, 0, 0)
    }

    private fun addToMask() {
        mergeIntoDraft()
        Toast.makeText(
            this,
            "${dotStrokes.size} mask dots added",
            Toast.LENGTH_LONG
        ).show()
        finish() // back to the editor, which reloads the merged draft
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP)
            && (state == State.GRACE || state == State.RECORDING)
        ) {
            // Cancel the run but keep everything gathered so far.
            for (g in activeGhosts.values) doneGhosts.add(g)
            activeGhosts.clear()
            autoMode = false
            if (doneGhosts.isEmpty()) {
                toIdle("Test cancelled. Start again when ready.")
            } else {
                finishTest()
            }
            return true
        }
        if (QuickApply.onKey(this, keyCode)) return true
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        releasePerformance()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ the test surface

    private inner class TestView(context: Context) : View(context) {

        private val dotPaint = Paint().apply {
            color = Color.argb(220, 220, 30, 30)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        private val bigPaint = Paint().apply {
            color = Color.rgb(55, 55, 65)
            textSize = 140f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        private val textPaint = Paint().apply {
            color = Color.rgb(55, 55, 65)
            textSize = 42f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }
        private val mutePaint = Paint().apply {
            color = Color.argb(230, 230, 150, 20)
            style = Paint.Style.STROKE
            strokeWidth = 6f
            pathEffect = android.graphics.DashPathEffect(floatArrayOf(28f, 18f), 0f)
            isAntiAlias = true
        }
        private val muteTextPaint = Paint().apply {
            color = Color.rgb(180, 120, 20)
            textSize = 34f
            textAlign = Paint.Align.CENTER
            isAntiAlias = true
        }

        init {
            // White: dead pixels stand out, and it doubles as a clean test field.
            setBackgroundColor(Color.WHITE)
        }

        /** The active pressure-mute zone center, or null when no zone is up. */
        fun muteZone(): Pair<Float, Float>? {
            if (state != State.RECORDING || width == 0) return null
            val elapsed = SystemClock.elapsedRealtime() - phaseStart
            val spots = arrayOf(
                0.25f to 0.30f, 0.75f to 0.30f, 0.50f to 0.52f,
                0.25f to 0.75f, 0.75f to 0.75f
            )
            // Each spot holds MUTE_EACH_MS, back to back; once we run past the
            // last one the remaining time has no safe zone — pure detection.
            val idx = (elapsed / MUTE_EACH_MS).toInt()
            if (idx >= spots.size) return null
            val (fx, fy) = spots[idx]
            return (fx * width) to (fy * height)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (state != State.RECORDING) return true
            eventCount++
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    try {
                        // Ask the system for maximum-rate delivery, no frame batching.
                        requestUnbufferedDispatch(event)
                    } catch (t: Throwable) {
                        // Best effort.
                    }
                    val idx = event.actionIndex
                    val id = event.getPointerId(idx)
                    val x = event.getRawX(idx)
                    val y = event.getRawY(idx)
                    val mz = muteZone()
                    if (mz != null) {
                        val dx = event.getX(idx) - mz.first
                        val dy = event.getY(idx) - mz.second
                        if (dx * dx + dy * dy <= MUTE_R * MUTE_R) {
                            // Your pressure finger: excluded from detection.
                            mutedIds.add(id)
                            return true
                        }
                    }
                    if (activeGhosts.size + doneGhosts.size < MAX_CONTACTS) {
                        val g = Ghost(x, y, eventNs(event))
                        recordSample(g, g.startNs, x, y)
                        activeGhosts[id] = g
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    val nowNs = eventNs(event)
                    for (i in 0 until event.pointerCount) {
                        val id = event.getPointerId(i)
                        if (mutedIds.contains(id)) continue
                        val g = activeGhosts[id] ?: continue
                        g.endNs = nowNs
                        // Local-to-raw offset for this event (historical getters are view-local).
                        val rawDx = event.getRawX(i) - event.getX(i)
                        val rawDy = event.getRawY(i) - event.getY(i)
                        // Batched intermediate samples first, oldest to newest.
                        for (h in 0 until event.historySize) {
                            val histNs = event.getHistoricalEventTime(h) * 1_000_000L
                            recordSample(g, histNs, event.getHistoricalX(i, h) + rawDx, event.getHistoricalY(i, h) + rawDy)
                        }
                        recordSample(g, nowNs, event.getRawX(i), event.getRawY(i))
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                    val id = event.getPointerId(event.actionIndex)
                    if (mutedIds.remove(id)) return true
                    val g = activeGhosts.remove(id)
                    if (g != null) {
                        g.endNs = eventNs(event)
                        doneGhosts.add(g)
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    val nowNs = eventNs(event)
                    mutedIds.clear()
                    for (g in activeGhosts.values) {
                        g.endNs = nowNs
                        doneGhosts.add(g)
                    }
                    activeGhosts.clear()
                }
            }
            // No invalidate() here: repainting at up to 240 Hz would steal the
            // main thread from input delivery. The 100 ms ticker repaints.
            return true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f
            val cy = height / 2f

            for (s in dotStrokes) {
                canvas.drawCircle(s.pts[0], s.pts[1], 6f, dotPaint)
            }

            when (state) {
                State.IDLE -> {
                    canvas.drawText("Ghost touch test", cx, cy - 40f, textPaint)
                    canvas.drawText("Tap Start, then hands off", cx, cy + 30f, textPaint)
                }
                State.GRACE -> {
                    canvas.drawText("Hands off\u2026", cx, cy, bigPaint)
                }
                State.RECORDING -> {
                    val elapsed = SystemClock.elapsedRealtime() - phaseStart
                    val remaining = TEST_SECONDS - (elapsed / 1000L).toInt()
                    canvas.drawText("$remaining", cx, cy, bigPaint)
                    canvas.drawText("touch nothing", cx, cy + 90f, textPaint)
                    canvas.drawText(
                        "contacts: ${doneGhosts.size + activeGhosts.size}   dots: ${dotStrokes.size}",
                        cx, cy + 160f, textPaint
                    )
                    val mz = muteZone()
                    if (mz != null) {
                        canvas.drawCircle(mz.first, mz.second, MUTE_R, mutePaint)
                        canvas.drawText("press here (optional)", mz.first, mz.second + MUTE_R + 44f, muteTextPaint)
                        canvas.drawText(
                            "flex the glass \u2014 this spot is ignored, ghosts elsewhere still count",
                            cx, cy + 230f, muteTextPaint
                        )
                    }
                }
                State.RESULTS -> {
                    canvas.drawText("Run done \u2014 totals below", cx, cy, textPaint)
                }
            }
        }
    }
}
