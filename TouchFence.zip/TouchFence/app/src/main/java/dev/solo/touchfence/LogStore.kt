package dev.solo.touchfence

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.WindowManager
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Persistent, exportable record of everything the auto tests observe, plus the
 * currently active mask — a machine-readable dataset for characterizing what a
 * ghost touch on this panel looks like.
 *
 * One flat CSV, rows tagged by first column:
 *   R,session,run,epoch_ms                  — a test run began
 *   C,run,contact,start_us_in_run,duration_us,samples,x0,y0
 *   S,contact,t_us_in_contact,x,y           — one raw coordinate sample
 *   M,rect,left,top,right,bottom            — active blocked rectangle
 *   D,stroke,index,width,npts,x0,y0         — mask draft stroke summary
 *   H,session,epoch_ms,touch-test-start|stop[,samples]  — scratch-pad session marker
 *   X,session,t_ns,action,pid,tool,rawX,rawY,x,y,pressure,size,
 *       touchMajor,touchMinor,toolMajor,toolMinor,orientation,edge,button,device,source
 *                                           — one full-fidelity scratch-pad touch sample
 *
 * The log survives app restarts and accumulates across sessions; clearing is
 * explicit. Sample rows from batched history carry millisecond-derived
 * timestamps; primary rows use the nanosecond clock where the OS provides it.
 */
object LogStore {

    private const val FILE_NAME = "ghost_log.csv"

    /** Refuse appends past this size until exported and cleared. */
    private const val MAX_BYTES = 32_000_000L

    private fun file(context: Context) = File(context.filesDir, FILE_NAME)

    /** Appends raw rows; returns false if the log is full. */
    fun append(context: Context, text: String): Boolean {
        val f = file(context)
        if (f.exists() && f.length() > MAX_BYTES) return false
        return try {
            f.appendText(text)
            true
        } catch (t: Throwable) {
            false
        }
    }

    fun read(context: Context): String = try {
        val f = file(context)
        if (f.exists()) f.readText() else ""
    } catch (t: Throwable) {
        ""
    }

    fun clear(context: Context) {
        try {
            file(context).delete()
        } catch (t: Throwable) {
            // Nothing to do.
        }
    }

    /** Full export: metadata, the active mask (rects + draft strokes), then the log. */
    fun buildExport(context: Context): String {
        val sb = StringBuilder()
        sb.append("# Ghost-TouchBlocker ghost data export\n")
        sb.append("# time,")
            .append(SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date()))
            .append('\n')
        sb.append("# device,").append(Build.MODEL)
            .append(",android,").append(Build.VERSION.RELEASE).append('\n')
        try {
            val wm = context.getSystemService(WindowManager::class.java)
            val b = wm.currentWindowMetrics.bounds
            sb.append("# screen,").append(b.width()).append(',').append(b.height()).append('\n')
        } catch (t: Throwable) {
            // Metadata only; skip.
        }
        sb.append("# rows: R,session,run,epoch_ms | ")
        sb.append("C,run,contact,start_us_in_run,duration_us,samples,x0,y0 | ")
        sb.append("S,contact,t_us_in_contact,x,y | ")
        sb.append("M,rect,l,t,r,b | D,stroke,i,width,npts,x0,y0 | ")
        sb.append("H,session,epoch_ms,touch-test | ")
        sb.append("X,session,t_ns,action,pid,tool,rawX,rawY,x,y,pressure,size,")
        sb.append("tMajor,tMinor,toolMajor,toolMinor,orient,edge,button,device,source\n")

        val rects = MaskStore.load(context)
        for ((i, r) in rects.withIndex()) {
            sb.append("M,").append(i + 1).append(',')
                .append(r.left).append(',').append(r.top).append(',')
                .append(r.right).append(',').append(r.bottom).append('\n')
        }
        val (strokes, _, _) = MaskStore.loadDraft(context)
        for ((i, s) in strokes.withIndex()) {
            sb.append("D,").append(i + 1).append(',')
                .append(s.width).append(',').append(s.pts.size / 2).append(',')
                .append(s.pts[0]).append(',').append(s.pts[1]).append('\n')
        }
        sb.append('\n')
        sb.append(read(context))
        return sb.toString()
    }

    /** Writes text into the shared Downloads folder; returns the file name, or null. */
    fun saveToDownloads(context: Context, text: String): String? {
        val name = "Ghost-TouchBlocker_" +
                SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".csv"
        return try {
            val values = ContentValues()
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            values.put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            val uri = context.contentResolver.insert(
                MediaStore.Downloads.EXTERNAL_CONTENT_URI, values
            ) ?: return null
            context.contentResolver.openOutputStream(uri)?.use { out ->
                out.write(text.toByteArray())
            } ?: return null
            name
        } catch (t: Throwable) {
            null
        }
    }
}
