package dev.solo.touchfence

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * Two-phase mask editor.
 *
 * Phase 1 (DRAW): scribble or circle a freeform shape anywhere BELOW the guard
 * line — i.e. in the half of the screen that still registers touch correctly.
 * The shape does not need to be in the right place, only the right size/outline.
 *
 * Phase 2 (POSITION): the shape is converted into at most [MAX_RECTS] rectangles,
 * shown as a translucent red mask, and a D-pad nudges the whole mask into place
 * over the physically damaged area. Hold an arrow to keep moving.
 */
class DrawMaskActivity : Activity() {

    companion object {
        /** Drawing input is only accepted below screenHeight * this fraction. */
        const val GUARD_FRACTION = 0.5f

        /** Hard cap on how many rectangles the shape is decomposed into. */
        const val MAX_RECTS = 128

        /** Starting grid cell size in px; doubles until the rect count fits the cap. */
        const val START_CELL_PX = 16

        /** Brush thickness in px — a plain scribbled line blocks this wide. */
        const val BRUSH_PX = 60f

        /** D-pad step sizes in px. */
        const val STEP_FINE = 20
        const val STEP_COARSE = 120
    }

    private enum class Mode { DRAW, POSITION }

    private lateinit var drawView: DrawView
    private lateinit var drawControls: LinearLayout
    private lateinit var positionControls: LinearLayout
    private lateinit var positionLabel: TextView
    private lateinit var stepButton: Button
    private var step = STEP_FINE

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        goEdgeToEdge()

        val bounds = windowManager.currentWindowMetrics.bounds
        val screenW = bounds.width()
        val screenH = bounds.height()

        val root = FrameLayout(this)
        drawView = DrawView(this, screenW, screenH)
        root.addView(
            drawView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        buildDrawControls()
        buildPositionControls()

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.addView(drawControls)
        panel.addView(positionControls)
        panel.setPadding(dp(16), 0, dp(16), dp(28))
        val panelLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        panelLp.gravity = Gravity.BOTTOM
        root.addView(panel, panelLp)

        setContentView(root)
        enterDrawMode()
    }

    private fun goEdgeToEdge() {
        window.setDecorFitsSystemWindows(false)
        val attrs = window.attributes
        attrs.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        window.attributes = attrs
        val controller = window.insetsController
        if (controller != null) {
            controller.hide(WindowInsets.Type.systemBars())
            controller.systemBarsBehavior =
                WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    // ------------------------------------------------------------------ controls

    private fun buildDrawControls() {
        drawControls = LinearLayout(this)
        drawControls.orientation = LinearLayout.HORIZONTAL

        addBarButton(drawControls, "Undo") { drawView.undoStroke() }
        addBarButton(drawControls, "Clear") { drawView.clearStrokes() }
        addBarButton(drawControls, "Done \u2192") {
            if (!drawView.hasStrokes()) {
                Toast.makeText(this, "Draw something first", Toast.LENGTH_SHORT).show()
            } else {
                enterPositionMode()
            }
        }
    }

    private fun buildPositionControls() {
        positionControls = LinearLayout(this)
        positionControls.orientation = LinearLayout.VERTICAL

        positionLabel = TextView(this)
        positionLabel.setTextColor(Color.WHITE)
        positionLabel.textSize = 15f
        positionLabel.gravity = Gravity.CENTER_HORIZONTAL
        positionLabel.setPadding(0, 0, 0, dp(8))
        positionControls.addView(positionLabel)

        // D-pad: up on its own row, then left / down / right.
        val topRow = LinearLayout(this)
        topRow.orientation = LinearLayout.HORIZONTAL
        topRow.gravity = Gravity.CENTER_HORIZONTAL
        addArrow(topRow, "\u25B2") { nudge(0, -step) }
        positionControls.addView(topRow)

        val midRow = LinearLayout(this)
        midRow.orientation = LinearLayout.HORIZONTAL
        midRow.gravity = Gravity.CENTER_HORIZONTAL
        addArrow(midRow, "\u25C0") { nudge(-step, 0) }
        addArrow(midRow, "\u25BC") { nudge(0, step) }
        addArrow(midRow, "\u25B6") { nudge(step, 0) }
        positionControls.addView(midRow)

        val bottomRow = LinearLayout(this)
        bottomRow.orientation = LinearLayout.HORIZONTAL
        stepButton = addBarButton(bottomRow, "Step: $STEP_FINE px") {
            step = if (step == STEP_FINE) STEP_COARSE else STEP_FINE
            stepButton.text = "Step: $step px"
        }
        addBarButton(bottomRow, "Redraw") { enterDrawMode() }
        addBarButton(bottomRow, "Save mask") { saveMask() }
        positionControls.addView(bottomRow)
    }

    private fun addBarButton(parent: LinearLayout, label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 16f
        b.minHeight = dp(52)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.leftMargin = dp(4)
        lp.rightMargin = dp(4)
        parent.addView(b, lp)
        return b
    }

    /** Arrow button that fires immediately, then repeats while held. */
    private fun addArrow(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this)
        b.text = label
        b.textSize = 22f
        val handler = Handler(Looper.getMainLooper())
        val repeater = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 60L)
            }
        }
        b.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    action()
                    handler.postDelayed(repeater, 350L)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(repeater)
                    true
                }
                else -> true
            }
        }
        val size = dp(72)
        val lp = LinearLayout.LayoutParams(size, size)
        lp.leftMargin = dp(6)
        lp.rightMargin = dp(6)
        lp.bottomMargin = dp(6)
        parent.addView(b, lp)
    }

    // ------------------------------------------------------------------ modes

    private fun enterDrawMode() {
        drawView.mode = Mode.DRAW
        drawControls.visibility = View.VISIBLE
        positionControls.visibility = View.GONE
        drawView.invalidate()
    }

    private fun enterPositionMode() {
        val rects = drawView.computeRects()
        if (rects.isEmpty()) {
            Toast.makeText(this, "Couldn't read the shape \u2014 try drawing thicker", Toast.LENGTH_SHORT).show()
            return
        }
        drawView.mode = Mode.POSITION
        drawControls.visibility = View.GONE
        positionControls.visibility = View.VISIBLE
        positionLabel.text = "${rects.size} rectangles \u2014 nudge the mask into place, then save"
        drawView.invalidate()
    }

    private fun nudge(dx: Int, dy: Int) {
        drawView.nudge(dx, dy)
    }

    private fun saveMask() {
        val finalRects = drawView.finalRects()
        if (finalRects.isEmpty()) {
            Toast.makeText(this, "Mask is entirely off-screen", Toast.LENGTH_SHORT).show()
            return
        }
        MaskStore.save(this, finalRects)
        Toast.makeText(this, "Saved ${finalRects.size} zones", Toast.LENGTH_SHORT).show()
        finish()
    }

    // ------------------------------------------------------------------ the canvas

    private inner class DrawView(
        context: Context,
        private val screenW: Int,
        private val screenH: Int
    ) : View(context) {

        var mode = Mode.DRAW

        private val guardY = screenH * GUARD_FRACTION

        private val strokes = mutableListOf<Path>()
        private var current: Path? = null

        private var rects: List<Rect> = emptyList()
        private var offsetX = 0
        private var offsetY = 0

        private val strokeFillPaint = Paint().apply {
            color = Color.argb(70, 80, 160, 255)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        private val strokeLinePaint = Paint().apply {
            color = Color.argb(200, 80, 160, 255)
            style = Paint.Style.STROKE
            strokeWidth = BRUSH_PX
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            isAntiAlias = true
        }
        private val guardPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.STROKE
            strokeWidth = 4f
            pathEffect = DashPathEffect(floatArrayOf(30f, 20f), 0f)
        }
        private val rectFillPaint = Paint().apply {
            color = Color.argb(70, 255, 59, 48)
            style = Paint.Style.FILL
        }
        private val rectLinePaint = Paint().apply {
            color = Color.argb(200, 255, 59, 48)
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        private val textPaint = Paint().apply {
            color = Color.WHITE
            textSize = 40f
            isAntiAlias = true
        }
        // Mask rasterization paints: opaque, no anti-aliasing, so cell coverage is crisp.
        private val maskFillPaint = Paint().apply {
            color = Color.RED
            style = Paint.Style.FILL
            isAntiAlias = false
        }
        private val maskLinePaint = Paint().apply {
            color = Color.RED
            style = Paint.Style.STROKE
            strokeWidth = BRUSH_PX
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            isAntiAlias = false
        }

        init {
            setBackgroundColor(Color.rgb(10, 10, 12))
        }

        fun hasStrokes(): Boolean = strokes.isNotEmpty()

        fun undoStroke() {
            if (strokes.isNotEmpty()) {
                strokes.removeAt(strokes.size - 1)
                invalidate()
            }
        }

        fun clearStrokes() {
            strokes.clear()
            invalidate()
        }

        fun nudge(dx: Int, dy: Int) {
            offsetX += dx
            offsetY += dy
            invalidate()
        }

        /** Rectangles with the D-pad offset applied, clipped to the screen. */
        fun finalRects(): List<Rect> {
            val out = mutableListOf<Rect>()
            for (r in rects) {
                val moved = Rect(r)
                moved.offset(offsetX, offsetY)
                if (moved.intersect(0, 0, screenW, screenH)) {
                    out.add(moved)
                }
            }
            return out
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (mode != Mode.DRAW) return true
            // Only the first pointer is honored: ghost touches arrive as extra
            // pointers (ACTION_POINTER_DOWN) and are ignored entirely.
            val x = event.rawX
            val y = max(event.rawY, guardY)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (event.rawY < guardY) return true // stroke must start in the safe zone
                    current = Path()
                    current?.moveTo(x, y)
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    current?.lineTo(x, y)
                    invalidate()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val c = current
                    if (c != null) {
                        c.lineTo(x, y)
                        strokes.add(c)
                        current = null
                        invalidate()
                    }
                }
            }
            return true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (mode == Mode.DRAW) {
                canvas.drawLine(0f, guardY, screenW.toFloat(), guardY, guardPaint)
                canvas.drawText("draw below this line", 40f, guardY + 60f, textPaint)
                canvas.drawText(
                    "Scribble or circle the bad area \u2014 you'll move it into place next",
                    40f, guardY + 120f, textPaint
                )
                for (p in strokes) drawShape(canvas, p)
                val c = current
                if (c != null) drawShape(canvas, c)
            } else {
                canvas.drawText("Nudge the red mask over the damage", 40f, screenH * 0.60f, textPaint)
                for (r in rects) {
                    val moved = Rect(r)
                    moved.offset(offsetX, offsetY)
                    canvas.drawRect(moved, rectFillPaint)
                    canvas.drawRect(moved, rectLinePaint)
                }
            }
        }

        private fun drawShape(canvas: Canvas, p: Path) {
            val closed = Path(p)
            closed.close()
            canvas.drawPath(closed, strokeFillPaint)
            canvas.drawPath(p, strokeLinePaint)
        }

        /**
         * Rasterize the drawn shape onto a coarse grid, then greedily merge covered
         * cells into rectangles (horizontal runs, then identical runs merged
         * vertically). If the result exceeds MAX_RECTS, the grid is coarsened and
         * the whole thing retried, so the result is always <= MAX_RECTS.
         */
        fun computeRects(): List<Rect> {
            var cell = START_CELL_PX
            while (true) {
                val cols = ceil(screenW.toFloat() / cell).toInt()
                val rows = ceil(screenH.toFloat() / cell).toInt()
                val bmp = Bitmap.createBitmap(cols, rows, Bitmap.Config.ARGB_8888)
                val c = Canvas(bmp)
                c.scale(cols.toFloat() / screenW, rows.toFloat() / screenH)
                for (p in strokes) {
                    val closed = Path(p)
                    closed.close()
                    c.drawPath(closed, maskFillPaint)
                    c.drawPath(p, maskLinePaint)
                }

                val merged = mergeGrid(bmp, cols, rows, cell)
                bmp.recycle()

                if (merged.size <= MAX_RECTS || cell >= 512) {
                    rects = if (merged.size <= MAX_RECTS) merged else merged.subList(0, MAX_RECTS)
                    offsetX = 0
                    offsetY = 0
                    return rects
                }
                cell *= 2
            }
        }

        private fun mergeGrid(bmp: Bitmap, cols: Int, rows: Int, cell: Int): List<Rect> {
            // Growing rectangle in grid units, keyed by its horizontal run.
            class Grow(val c0: Int, val c1: Int, val r0: Int, var r1: Int)

            val all = mutableListOf<Grow>()
            var prev = HashMap<Long, Grow>()

            for (r in 0 until rows) {
                val cur = HashMap<Long, Grow>()
                var col = 0
                while (col < cols) {
                    if (Color.alpha(bmp.getPixel(col, r)) != 0) {
                        val start = col
                        while (col < cols && Color.alpha(bmp.getPixel(col, r)) != 0) col++
                        val end = col - 1
                        val key = start.toLong() shl 32 or end.toLong()
                        val g = prev[key]
                        if (g != null && g.r1 == r - 1) {
                            g.r1 = r
                            cur[key] = g
                        } else {
                            val n = Grow(start, end, r, r)
                            all.add(n)
                            cur[key] = n
                        }
                    } else {
                        col++
                    }
                }
                prev = cur
            }

            return all.map { g ->
                Rect(
                    g.c0 * cell,
                    g.r0 * cell,
                    min((g.c1 + 1) * cell, screenW),
                    min((g.r1 + 1) * cell, screenH)
                )
            }
        }
    }
}
