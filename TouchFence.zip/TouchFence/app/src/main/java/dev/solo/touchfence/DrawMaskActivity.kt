package dev.solo.touchfence

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * Two-phase mask editor.
 *
 * Phase 1 (DRAW): white canvas (so dead/dark pixels stand out). Scribble or
 * circle freeform shapes below the guard line with an adjustable brush. Tap a
 * stroke to select it (turns orange) and delete it. Hold the "Anywhere"
 * button to lift the guard line and draw over the damaged region directly.
 * A previously saved mask is restored here, exactly as drawn.
 *
 * Phase 2 (POSITION): the strokes become at most [MAX_RECTS] rectangles and a
 * D-pad nudges the whole mask into place. The last saved offset is restored,
 * so an edited mask lands where it was.
 */
class DrawMaskActivity : Activity() {

    companion object {
        /** Drawing input is only accepted below screenHeight * this fraction (unless Anywhere is on). */
        const val GUARD_FRACTION = 0.5f

        /** Hard cap on how many rectangles the shape is decomposed into. */
        const val MAX_RECTS = 128

        /** Starting grid cell size in px; doubles until the rect count fits the cap. */
        const val START_CELL_PX = 8

        /** Brush width slider range and default, in px. */
        const val MIN_BRUSH_PX = 10
        const val MAX_BRUSH_PX = 200
        const val DEFAULT_BRUSH_PX = 60

        /** D-pad step sizes in px. */
        const val STEP_FINE = 20
        const val STEP_COARSE = 120

        /** A touch that moves less than this is a tap (selection), not a stroke. */
        const val TAP_SLOP_PX = 16f

        /** Extra selection radius around a stroke beyond half its width. */
        const val SELECT_EXTRA_PX = 40f

        /** Minimum spacing between recorded stroke points. */
        const val MIN_POINT_GAP_PX = 3f
    }

    private enum class Mode { DRAW, POSITION }

    private lateinit var drawView: DrawView
    private lateinit var drawControls: LinearLayout
    private lateinit var positionControls: LinearLayout
    private lateinit var positionLabel: TextView
    private lateinit var brushLabel: TextView
    private lateinit var anywhereButton: Button
    private lateinit var stepButton: Button
    private var step = STEP_FINE

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    private var awaitingCalibration = false

    override fun onResume() {
        super.onResume()
        if (awaitingCalibration) {
            awaitingCalibration = false
            val (strokes, ox, oy) = MaskStore.loadDraft(this)
            drawView.reload(strokes, ox, oy)
            enterDrawMode()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Prefer the true display bounds; fall back to displayMetrics if the
        // newer API misbehaves on this OS build. The D-pad exists precisely to
        // absorb any small coordinate-space difference.
        var screenW: Int
        var screenH: Int
        try {
            val bounds = windowManager.currentWindowMetrics.bounds
            screenW = bounds.width()
            screenH = bounds.height()
        } catch (t: Throwable) {
            val dm = resources.displayMetrics
            screenW = dm.widthPixels
            screenH = dm.heightPixels
        }

        // Restore the previous drawing and its saved position, if any.
        val (savedStrokes, savedOx, savedOy) = MaskStore.loadDraft(this)

        val root = FrameLayout(this)
        drawView = DrawView(this, screenW, screenH, savedStrokes, savedOx, savedOy)
        root.addView(
            drawView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        buildDrawControls()
        buildPositionControls()

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.addView(drawControls)
        panel.addView(positionControls)
        panel.setPadding(dp(16), dp(10), dp(16), dp(28))
        panel.setBackgroundColor(Color.argb(195, 16, 16, 20))
        val panelLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        panelLp.gravity = Gravity.BOTTOM
        root.addView(panel, panelLp)

        setContentView(root)
        goEdgeToEdge()
        enterDrawMode()
    }

    /**
     * All cosmetic: extends the canvas behind the system bars and hides them.
     * Every step is individually shielded — if this OS build rejects any of it,
     * the screen simply runs slightly less than fullscreen instead of crashing.
     * Mask alignment does not depend on this (geometry uses raw screen coords).
     */
    private fun goEdgeToEdge() {
        try {
            window.setDecorFitsSystemWindows(false)
        } catch (t: Throwable) {
            // Cosmetic only; ignore.
        }
        try {
            val attrs = window.attributes
            attrs.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            window.attributes = attrs
        } catch (t: Throwable) {
            // Cosmetic only; ignore.
        }
        try {
            val controller = window.insetsController
            if (controller != null) {
                controller.hide(WindowInsets.Type.systemBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } catch (t: Throwable) {
            // Cosmetic only; ignore.
        }
    }

    // ------------------------------------------------------------------ controls

    private fun buildDrawControls() {
        drawControls = LinearLayout(this)
        drawControls.orientation = LinearLayout.VERTICAL

        // Brush size slider.
        brushLabel = TextView(this)
        brushLabel.text = "Brush: $DEFAULT_BRUSH_PX px"
        brushLabel.setTextColor(Color.WHITE)
        brushLabel.textSize = 14f
        drawControls.addView(brushLabel)

        val seek = SeekBar(this)
        seek.min = MIN_BRUSH_PX
        seek.max = MAX_BRUSH_PX
        seek.progress = DEFAULT_BRUSH_PX
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                drawView.brushWidth = value.toFloat()
                brushLabel.text = "Brush: $value px"
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        val seekLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        seekLp.bottomMargin = dp(6)
        drawControls.addView(seek, seekLp)

        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        addBarButton(row1, "Undo") { drawView.undoStroke() }
        addBarButton(row1, "Delete") {
            if (!drawView.deleteSelected()) {
                Toast.makeText(this, "Tap a stroke to select it first", Toast.LENGTH_SHORT).show()
            }
        }
        addBarButton(row1, "Clear") { drawView.clearStrokes() }
        drawControls.addView(row1)

        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        addBarButton(row2, "Auto test") {
            // Persist the working drawing so the test's findings merge into it.
            MaskStore.saveDraft(this, drawView.strokes, drawView.offsetX, drawView.offsetY)
            awaitingCalibration = true
            startActivity(Intent(this, CalibrateActivity::class.java))
        }
        anywhereButton = addBarButton(row2, "Anywhere: OFF") {
            Toast.makeText(this, "Press and hold to toggle", Toast.LENGTH_SHORT).show()
        }
        anywhereButton.setOnLongClickListener {
            drawView.anywhere = !drawView.anywhere
            anywhereButton.text = if (drawView.anywhere) "Anywhere: ON" else "Anywhere: OFF"
            drawView.invalidate()
            true
        }
        addBarButton(row2, "Done \u2192") {
            if (drawView.strokes.isEmpty()) {
                Toast.makeText(this, "Draw something first", Toast.LENGTH_SHORT).show()
            } else {
                enterPositionMode()
            }
        }
        drawControls.addView(row2)
    }

    private fun buildPositionControls() {
        positionControls = LinearLayout(this)
        positionControls.orientation = LinearLayout.VERTICAL

        positionLabel = TextView(this)
        positionLabel.setTextColor(Color.WHITE)
        positionLabel.textSize = 15f
        positionLabel.gravity = Gravity.CENTER_HORIZONTAL
        positionLabel.setPadding(0, 0, 0, dp(8))
        positionControls.addView(positionLabel)

        // D-pad: up on its own row, then left / down / right.
        val topRow = LinearLayout(this)
        topRow.orientation = LinearLayout.HORIZONTAL
        topRow.gravity = Gravity.CENTER_HORIZONTAL
        addArrow(topRow, "\u25B2") { nudge(0, -step) }
        positionControls.addView(topRow)

        val midRow = LinearLayout(this)
        midRow.orientation = LinearLayout.HORIZONTAL
        midRow.gravity = Gravity.CENTER_HORIZONTAL
        addArrow(midRow, "\u25C0") { nudge(-step, 0) }
        addArrow(midRow, "\u25BC") { nudge(0, step) }
        addArrow(midRow, "\u25B6") { nudge(step, 0) }
        positionControls.addView(midRow)

        val bottomRow = LinearLayout(this)
        bottomRow.orientation = LinearLayout.HORIZONTAL
        stepButton = addBarButton(bottomRow, "Step: $STEP_FINE px") {
            step = if (step == STEP_FINE) STEP_COARSE else STEP_FINE
            stepButton.text = "Step: $step px"
        }
        addBarButton(bottomRow, "Redraw") { enterDrawMode() }
        addBarButton(bottomRow, "Save mask") { saveMask() }
        positionControls.addView(bottomRow)
    }

    private fun addBarButton(parent: LinearLayout, label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 16f
        b.minHeight = dp(52)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.leftMargin = dp(4)
        lp.rightMargin = dp(4)
        parent.addView(b, lp)
        return b
    }

    /** Arrow button that fires immediately, then repeats while held. */
    private fun addArrow(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this)
        b.text = label
        b.textSize = 22f
        val handler = Handler(Looper.getMainLooper())
        val repeater = object : Runnable {
            override fun run() {
                action()
                handler.postDelayed(this, 60L)
            }
        }
        b.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    action()
                    handler.postDelayed(repeater, 350L)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(repeater)
                    true
                }
                else -> true
            }
        }
        val size = dp(72)
        val lp = LinearLayout.LayoutParams(size, size)
        lp.leftMargin = dp(6)
        lp.rightMargin = dp(6)
        lp.bottomMargin = dp(6)
        parent.addView(b, lp)
    }

    // ------------------------------------------------------------------ modes

    private fun enterDrawMode() {
        drawView.mode = Mode.DRAW
        drawControls.visibility = View.VISIBLE
        positionControls.visibility = View.GONE
        drawView.invalidate()
    }

    private fun enterPositionMode() {
        val rects = try {
            drawView.computeRects()
        } catch (t: Throwable) {
            Toast.makeText(this, "Shape conversion failed: $t", Toast.LENGTH_LONG).show()
            return
        }
        if (rects.isEmpty()) {
            Toast.makeText(this, "Couldn't read the shape \u2014 try drawing thicker", Toast.LENGTH_SHORT).show()
            return
        }
        drawView.mode = Mode.POSITION
        drawControls.visibility = View.GONE
        positionControls.visibility = View.VISIBLE
        positionLabel.text = "${rects.size} rectangles \u2014 nudge the mask into place, then save"
        drawView.invalidate()
    }

    private fun nudge(dx: Int, dy: Int) {
        drawView.nudge(dx, dy)
    }

    private fun saveMask() {
        val finalRects = drawView.finalRects()
        if (finalRects.isEmpty()) {
            Toast.makeText(this, "Mask is entirely off-screen", Toast.LENGTH_SHORT).show()
            return
        }
        MaskStore.save(this, finalRects)
        MaskStore.saveDraft(this, drawView.strokes, drawView.offsetX, drawView.offsetY)
        Toast.makeText(this, "Saved ${finalRects.size} zones", Toast.LENGTH_SHORT).show()
        finish()
    }

    // ------------------------------------------------------------------ the canvas

    private inner class DrawView(
        context: Context,
        private val screenW: Int,
        private val screenH: Int,
        val strokes: MutableList<Stroke>,
        var offsetX: Int,
        var offsetY: Int
    ) : View(context) {

        var mode = Mode.DRAW
        var brushWidth = DEFAULT_BRUSH_PX.toFloat()
        var anywhere = false

        private val guardY = screenH * GUARD_FRACTION

        private var current: Stroke? = null
        private var selected: Stroke? = null

        private var downX = 0f
        private var downY = 0f
        private var moved = false

        private var rects: List<Rect> = emptyList()

        private val strokeFillPaint = Paint().apply {
            color = Color.argb(60, 60, 130, 240)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        private val strokeLinePaint = Paint().apply {
            color = Color.argb(190, 60, 130, 240)
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            isAntiAlias = true
        }
        private val selectedFillPaint = Paint().apply {
            color = Color.argb(70, 255, 150, 0)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        private val selectedLinePaint = Paint().apply {
            color = Color.argb(220, 255, 150, 0)
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            isAntiAlias = true
        }
        private val guardPaint = Paint().apply {
            color = Color.rgb(30, 30, 34)
            style = Paint.Style.STROKE
            strokeWidth = 4f
            pathEffect = DashPathEffect(floatArrayOf(30f, 20f), 0f)
        }
        private val rectFillPaint = Paint().apply {
            color = Color.argb(70, 255, 59, 48)
            style = Paint.Style.FILL
        }
        private val rectLinePaint = Paint().apply {
            color = Color.argb(200, 255, 59, 48)
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        private val textPaint = Paint().apply {
            color = Color.rgb(55, 55, 65)
            textSize = 40f
            isAntiAlias = true
        }
        // Mask rasterization paints: opaque, no anti-aliasing, so cell coverage is crisp.
        private val maskFillPaint = Paint().apply {
            color = Color.RED
            style = Paint.Style.FILL
            isAntiAlias = false
        }
        private val maskLinePaint = Paint().apply {
            color = Color.RED
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            isAntiAlias = false
        }

        init {
            // White canvas: dead/dark pixels stand out against it.
            setBackgroundColor(Color.WHITE)
        }

        fun reload(newStrokes: List<Stroke>, ox: Int, oy: Int) {
            strokes.clear()
            strokes.addAll(newStrokes)
            offsetX = ox
            offsetY = oy
            selected = null
            current = null
            invalidate()
        }

        fun undoStroke() {
            if (strokes.isNotEmpty()) {
                val removed = strokes.removeAt(strokes.size - 1)
                if (selected === removed) selected = null
                invalidate()
            }
        }

        fun deleteSelected(): Boolean {
            val s = selected ?: return false
            strokes.remove(s)
            selected = null
            invalidate()
            return true
        }

        fun clearStrokes() {
            strokes.clear()
            selected = null
            invalidate()
        }

        fun nudge(dx: Int, dy: Int) {
            offsetX += dx
            offsetY += dy
            invalidate()
        }

        /** Rectangles with the D-pad offset applied, clipped to the screen. */
        fun finalRects(): List<Rect> {
            val out = mutableListOf<Rect>()
            for (r in rects) {
                val movedRect = Rect(r)
                movedRect.offset(offsetX, offsetY)
                if (movedRect.intersect(0, 0, screenW, screenH)) {
                    out.add(movedRect)
                }
            }
            return out
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (mode != Mode.DRAW) return true
            // Only the first pointer is honored: ghost touches arrive as extra
            // pointers (ACTION_POINTER_DOWN) and are ignored entirely.
            val rawX = event.rawX
            val rawY = event.rawY
            val y = if (anywhere) rawY else max(rawY, guardY)
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (!anywhere && rawY < guardY) return true // must start in the safe zone
                    downX = rawX
                    downY = y
                    moved = false
                    val s = Stroke(brushWidth)
                    s.add(rawX, y)
                    current = s
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    val s = current ?: return true
                    val ddx = rawX - downX
                    val ddy = y - downY
                    if (ddx * ddx + ddy * ddy > TAP_SLOP_PX * TAP_SLOP_PX) moved = true
                    val gx = rawX - s.lastX()
                    val gy = y - s.lastY()
                    if (gx * gx + gy * gy >= MIN_POINT_GAP_PX * MIN_POINT_GAP_PX) {
                        s.add(rawX, y)
                        invalidate()
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val s = current ?: return true
                    current = null
                    if (moved) {
                        s.add(rawX, y)
                        strokes.add(s)
                        selected = null
                    } else {
                        // A tap: select (or deselect) instead of adding a dot.
                        selected = hitTest(downX, downY)
                    }
                    invalidate()
                }
            }
            return true
        }

        /** Finds the topmost stroke near the tap point, or null. */
        private fun hitTest(x: Float, y: Float): Stroke? {
            for (i in strokes.indices.reversed()) {
                val s = strokes[i]
                val thr = s.width / 2f + SELECT_EXTRA_PX
                val thr2 = thr * thr
                var j = 0
                while (j + 1 < s.pts.size) {
                    val dx = s.pts[j] - x
                    val dy = s.pts[j + 1] - y
                    if (dx * dx + dy * dy <= thr2) return s
                    j += 2
                }
            }
            return null
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            if (mode == Mode.DRAW) {
                if (anywhere) {
                    canvas.drawText("Draw anywhere is ON \u2014 careful up top", 40f, guardY + 60f, textPaint)
                } else {
                    canvas.drawLine(0f, guardY, screenW.toFloat(), guardY, guardPaint)
                    canvas.drawText("draw below this line", 40f, guardY + 60f, textPaint)
                }
                canvas.drawText("Tap a stroke to select it \u2022 drag to draw", 40f, guardY + 120f, textPaint)
                for (s in strokes) {
                    drawStroke(canvas, s, s === selected)
                }
                val c = current
                if (c != null) drawStroke(canvas, c, false)
            } else {
                canvas.drawText("Nudge the red mask over the damage", 40f, screenH * 0.42f, textPaint)
                for (r in rects) {
                    val movedRect = Rect(r)
                    movedRect.offset(offsetX, offsetY)
                    canvas.drawRect(movedRect, rectFillPaint)
                    canvas.drawRect(movedRect, rectLinePaint)
                }
            }
        }

        private fun drawStroke(canvas: Canvas, s: Stroke, isSelected: Boolean) {
            val fill = if (isSelected) selectedFillPaint else strokeFillPaint
            val line = if (isSelected) selectedLinePaint else strokeLinePaint
            line.strokeWidth = s.width
            val closed = Path(s.path)
            closed.close()
            canvas.drawPath(closed, fill)
            canvas.drawPath(s.path, line)
        }

        /**
         * Rasterize the drawn shape onto a coarse grid, then greedily merge covered
         * cells into rectangles (horizontal runs, then identical runs merged
         * vertically). If the result exceeds MAX_RECTS, the grid is coarsened and
         * the whole thing retried, so the result is always <= MAX_RECTS.
         * The current D-pad offset is kept, so an edited mask lands where it was.
         */
        fun computeRects(): List<Rect> {
            var cell = START_CELL_PX
            while (true) {
                val cols = ceil(screenW.toFloat() / cell).toInt()
                val rows = ceil(screenH.toFloat() / cell).toInt()
                val bmp = Bitmap.createBitmap(cols, rows, Bitmap.Config.ARGB_8888)
                val c = Canvas(bmp)
                c.scale(cols.toFloat() / screenW, rows.toFloat() / screenH)
                for (s in strokes) {
                    maskLinePaint.strokeWidth = s.width
                    val closed = Path(s.path)
                    closed.close()
                    c.drawPath(closed, maskFillPaint)
                    c.drawPath(s.path, maskLinePaint)
                }

                val mergedRects = mergeGrid(bmp, cols, rows, cell)
                bmp.recycle()

                if (mergedRects.size <= MAX_RECTS || cell >= 512) {
                    rects = if (mergedRects.size <= MAX_RECTS) mergedRects
                    else mergedRects.subList(0, MAX_RECTS)
                    return rects
                }
                cell *= 2
            }
        }

        private fun mergeGrid(bmp: Bitmap, cols: Int, rows: Int, cell: Int): List<Rect> {
            // Growing rectangle in grid units, keyed by its horizontal run.
            class Grow(val c0: Int, val c1: Int, val r0: Int, var r1: Int)

            val all = mutableListOf<Grow>()
            var prev = HashMap<Long, Grow>()

            for (r in 0 until rows) {
                val cur = HashMap<Long, Grow>()
                var col = 0
                while (col < cols) {
                    if (Color.alpha(bmp.getPixel(col, r)) != 0) {
                        val start = col
                        while (col < cols && Color.alpha(bmp.getPixel(col, r)) != 0) col++
                        val end = col - 1
                        val key = start.toLong() shl 32 or end.toLong()
                        val g = prev[key]
                        if (g != null && g.r1 == r - 1) {
                            g.r1 = r
                            cur[key] = g
                        } else {
                            val n = Grow(start, end, r, r)
                            all.add(n)
                            cur[key] = n
                        }
                    } else {
                        col++
                    }
                }
                prev = cur
            }

            return all.map { g ->
                Rect(
                    g.c0 * cell,
                    g.r0 * cell,
                    min((g.c1 + 1) * cell, screenW),
                    min((g.r1 + 1) * cell, screenH)
                )
            }
        }
    }
}
