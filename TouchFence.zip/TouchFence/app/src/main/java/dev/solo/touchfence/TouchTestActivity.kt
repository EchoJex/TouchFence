package dev.solo.touchfence

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.PowerManager
import android.os.Process
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Raw touch scratch pad / diagnostic. Runs inside Ghost-TouchBlocker's OWN window, so it
 * gets the full-fidelity MotionEvent stream (coords, pressure, size, tool axes)
 * with NO accessibility and NO freeze risk. Draws exactly where the panel
 * registers your finger — so you can map dead vs. live regions directly — and
 * logs every characteristic of every sample to LogStore (X rows).
 *
 * While the pad is open every performance lever is forced on (max refresh rate,
 * partial wake lock, urgent-display thread priority, unbuffered dispatch), and
 * all of them are captured first and restored to their original state on exit.
 */
class TouchTestActivity : Activity() {

    private lateinit var pad: PadView
    private lateinit var counter: TextView

    private var wakeLock: PowerManager.WakeLock? = null
    private var savedThreadPriority: Int? = null
    private var savedRefreshRate: Float? = null

    private val sessionId = System.currentTimeMillis()
    private var samples = 0L
    private val activePointers = HashSet<Int>()
    private var contacts = 0L

    // Off-main writer so file IO never stalls the capture/draw loop.
    private val writerThread = HandlerThread("touchtest-writer").apply { start() }
    private val writerH = Handler(writerThread.looper)
    private val bufferLock = Any()
    private val buffer = StringBuilder()

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Blocking overlays would eat the very touches we're testing.
        stopService(android.content.Intent(this, BlockerService::class.java))

        val root = FrameLayout(this)
        pad = PadView(this)
        root.addView(
            pad,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(16), dp(12), dp(16), dp(28))
        panel.setBackgroundColor(Color.argb(200, 16, 16, 20))

        counter = TextView(this)
        counter.setTextColor(Color.rgb(220, 220, 228))
        counter.textSize = 13f
        counter.text = "Drag anywhere. Red = where the panel registers your finger."
        panel.addView(counter)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        addButton(row, "Clear") { pad.clear() }
        addButton(row, "Save log") {
            flush()
            val name = LogStore.saveToDownloads(this, LogStore.buildExport(this))
            Toast.makeText(
                this,
                if (name != null) "Saved to Downloads as $name" else "Save failed",
                Toast.LENGTH_LONG
            ).show()
        }
        addButton(row, "Close") { finish() }
        panel.addView(row)

        val panelLp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        panelLp.gravity = Gravity.BOTTOM
        root.addView(panel, panelLp)

        setContentView(root)
        goEdgeToEdge()
        appendRaw("H,$sessionId,${System.currentTimeMillis()},touch-test-start\n")
    }

    private fun addButton(parent: LinearLayout, label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 15f
        b.minHeight = dp(52)
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        lp.leftMargin = dp(4)
        lp.rightMargin = dp(4)
        parent.addView(b, lp)
        return b
    }

    override fun onResume() {
        super.onResume()
        boostPerformance()
    }

    override fun onPause() {
        releasePerformance()
        flush()
        super.onPause()
    }

    override fun onDestroy() {
        appendRaw("H,$sessionId,${System.currentTimeMillis()},touch-test-stop,$samples\n")
        flush()
        writerThread.quitSafely()
        super.onDestroy()
    }

    // ------------------------------------------------------------ performance

    private fun boostPerformance() {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try {
            if (savedThreadPriority == null) savedThreadPriority = Process.getThreadPriority(Process.myTid())
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY)
        } catch (t: Throwable) {
            // Best effort.
        }
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Ghost-TouchBlocker:touchtest")
            wakeLock?.acquire(30 * 60 * 1000L)
        } catch (t: Throwable) {
            // Best effort.
        }
        try {
            val modes = display?.supportedModes
            if (modes != null && modes.isNotEmpty()) {
                var best = 0f
                for (m in modes) if (m.refreshRate > best) best = m.refreshRate
                val attrs = window.attributes
                if (savedRefreshRate == null) savedRefreshRate = attrs.preferredRefreshRate
                attrs.preferredRefreshRate = best
                window.attributes = attrs
            }
        } catch (t: Throwable) {
            // Best effort.
        }
        // Sustained-performance mode is left OFF on purpose so the SoC can turbo.
    }

    private fun releasePerformance() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        try {
            Process.setThreadPriority(savedThreadPriority ?: Process.THREAD_PRIORITY_DEFAULT)
        } catch (t: Throwable) {
            // Best effort.
        }
        savedThreadPriority = null
        savedRefreshRate?.let { original ->
            try {
                val attrs = window.attributes
                attrs.preferredRefreshRate = original
                window.attributes = attrs
            } catch (t: Throwable) {
                // Best effort.
            }
        }
        savedRefreshRate = null
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (t: Throwable) {
            // Already released.
        }
        wakeLock = null
    }

    private fun goEdgeToEdge() {
        try { window.setDecorFitsSystemWindows(false) } catch (t: Throwable) {}
        try {
            val attrs = window.attributes
            attrs.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            window.attributes = attrs
        } catch (t: Throwable) {}
        try {
            val c = window.insetsController
            if (c != null) {
                c.hide(WindowInsets.Type.systemBars())
                c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } catch (t: Throwable) {}
    }

    // ------------------------------------------------------------ writer

    private fun appendRaw(text: String) {
        synchronized(bufferLock) { buffer.append(text) }
        if (buffer.length >= 48_000) writerH.post { flush() }
    }

    private fun flush() {
        val chunk: String
        synchronized(bufferLock) {
            if (buffer.isEmpty()) return
            chunk = buffer.toString()
            buffer.setLength(0)
        }
        LogStore.append(this, chunk)
    }

    // ------------------------------------------------------------ the pad

    private inner class PadView(context: Context) : View(context) {

        // Points to draw: x, y, colorByPressure. Kept as parallel float lists.
        private val xs = ArrayList<Float>()
        private val ys = ArrayList<Float>()
        private val rs = ArrayList<Float>()
        private val dot = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
        private val hint = Paint().apply {
            color = Color.rgb(150, 150, 158); textSize = 34f; isAntiAlias = true
        }

        init { setBackgroundColor(Color.WHITE) }

        fun clear() {
            xs.clear(); ys.clear(); rs.clear(); invalidate()
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                    try { requestUnbufferedDispatch(event) } catch (t: Throwable) {}
                    val id = event.getPointerId(event.actionIndex)
                    if (activePointers.add(id)) contacts++
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                    activePointers.remove(event.getPointerId(event.actionIndex))
                }
            }

            val action = event.actionMasked
            val edge = event.edgeFlags
            val btn = event.buttonState
            val dev = event.deviceId
            val src = event.source
            val nowNs = try { event.eventTimeNanos } catch (t: Throwable) { event.eventTime * 1_000_000L }

            for (p in 0 until event.pointerCount) {
                val rawDx = event.getRawX(p) - event.getX(p)
                val rawDy = event.getRawY(p) - event.getY(p)
                // Batched historical samples first, oldest -> newest.
                for (h in 0 until event.historySize) {
                    logSample(
                        event.getHistoricalEventTime(h) * 1_000_000L, action, event.getPointerId(p),
                        event.getToolType(p),
                        event.getHistoricalX(p, h) + rawDx, event.getHistoricalY(p, h) + rawDy,
                        event.getHistoricalX(p, h), event.getHistoricalY(p, h),
                        event.getHistoricalPressure(p, h), event.getHistoricalSize(p, h),
                        event.getHistoricalTouchMajor(p, h), event.getHistoricalTouchMinor(p, h),
                        event.getHistoricalToolMajor(p, h), event.getHistoricalToolMinor(p, h),
                        event.getHistoricalOrientation(p, h), edge, btn, dev, src
                    )
                    addPoint(event.getHistoricalX(p, h), event.getHistoricalY(p, h), event.getHistoricalPressure(p, h))
                }
                logSample(
                    nowNs, action, event.getPointerId(p), event.getToolType(p),
                    event.getRawX(p), event.getRawY(p), event.getX(p), event.getY(p),
                    event.getPressure(p), event.getSize(p),
                    event.getTouchMajor(p), event.getTouchMinor(p),
                    event.getToolMajor(p), event.getToolMinor(p),
                    event.getOrientation(p), edge, btn, dev, src
                )
                addPoint(event.getX(p), event.getY(p), event.getPressure(p))
            }

            counter.text = "samples: $samples   contacts: $contacts   pointers: ${event.pointerCount}"
            invalidate()
            return true
        }

        private fun addPoint(x: Float, y: Float, pressure: Float) {
            xs.add(x); ys.add(y); rs.add(4f + pressure.coerceIn(0f, 2f) * 10f)
        }

        /** X,session,t_ns,action,pid,tool,rawX,rawY,x,y,press,size,tMaj,tMin,toolMaj,toolMin,orient,edge,btn,dev,src */
        private fun logSample(
            tNs: Long, action: Int, pid: Int, tool: Int,
            rawX: Float, rawY: Float, x: Float, y: Float,
            pressure: Float, size: Float,
            tMajor: Float, tMinor: Float, toolMajor: Float, toolMinor: Float,
            orient: Float, edge: Int, btn: Int, dev: Int, src: Int
        ) {
            samples++
            val sb = StringBuilder(96)
            sb.append("X,").append(sessionId).append(',').append(tNs).append(',')
                .append(action).append(',').append(pid).append(',').append(tool).append(',')
                .append(rawX).append(',').append(rawY).append(',')
                .append(x).append(',').append(y).append(',')
                .append(pressure).append(',').append(size).append(',')
                .append(tMajor).append(',').append(tMinor).append(',')
                .append(toolMajor).append(',').append(toolMinor).append(',')
                .append(orient).append(',').append(edge).append(',').append(btn).append(',')
                .append(dev).append(',').append(src).append('\n')
            appendRaw(sb.toString())
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            var i = 0
            while (i < xs.size) {
                // Brighter/larger with pressure; red so live regions stand out on white.
                dot.color = Color.argb(200, 220, 30, 30)
                canvas.drawCircle(xs[i], ys[i], rs[i], dot)
                i++
            }
            if (xs.isEmpty()) {
                canvas.drawText("Drag across the whole screen — dead zones leave blank gaps.", 40f, height * 0.5f, hint)
            }
        }
    }
}
