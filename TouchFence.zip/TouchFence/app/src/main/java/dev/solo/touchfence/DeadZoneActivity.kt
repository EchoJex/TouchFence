package dev.solo.touchfence

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/**
 * Dead-zone mapper — the inverse of the mask editor. You drag over everywhere
 * the screen STILL RESPONDS; the app then treats everything you *couldn't* reach
 * as dead and blocks it. Because a broken digitizer region won't register your
 * finger, you simply can't paint it — so it falls out as a blocked zone.
 *
 * To keep sloppy coverage from leaving good pixels "dead", the painted area is
 * dilated by [DILATE_PX] before inverting: any cell within that radius of a
 * stroke counts as functional. Then the dead cells are merged into rectangles
 * (horizontal runs + vertical merge) and saved as the active mask, sized to the
 * current resolution (MaskStore stores dims for rescale).
 *
 * A confirmation shows how much of the screen would be blocked, so a too-sparse
 * drawing can't silently blank most of the display.
 */
class DeadZoneActivity : Activity() {

    companion object {
        /** Rasterization grid cell, px. */
        const val CELL_PX = 40
        /** "A stroke within this many px marks that spot functional" — fills gaps
         *  between haphazard strokes so good areas aren't presumed dead. */
        const val DILATE_PX = 70
        /** A grid row/column at least this fraction dead is completed to the full
         *  width/height — a dead digitizer line is a whole row or column of
         *  electrodes, so partial dead bands extend to entire rows/columns. */
        const val ROW_COL_FILL_FRAC = 0.6f
        /** Painting brush width, px (wide, since we're mapping coverage). */
        const val BRUSH_PX = 120f
        /** Refuse to generate if less than this fraction was painted (avoid blocking nearly everything). */
        const val MIN_FUNCTIONAL_FRAC = 0.15f
    }

    private lateinit var view: MapView
    private lateinit var info: TextView
    private var screenW = 0
    private var screenH = 0

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // The blocker's overlays would eat the strokes we're mapping with.
        stopService(Intent(this, BlockerService::class.java))

        try {
            val b = windowManager.currentWindowMetrics.bounds
            screenW = b.width(); screenH = b.height()
        } catch (t: Throwable) {
            screenW = resources.displayMetrics.widthPixels
            screenH = resources.displayMetrics.heightPixels
        }

        val root = FrameLayout(this)
        view = MapView(this)
        root.addView(
            view,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding(dp(16), dp(12), dp(16), dp(28))
        panel.setBackgroundColor(Color.argb(205, 16, 16, 20))

        info = TextView(this)
        info.setTextColor(Color.rgb(220, 220, 228))
        info.textSize = 14f
        info.text = "Drag over EVERYWHERE the screen still responds — cover as much as you can, " +
                "corners and edges included. Wherever your finger can't register (dead spots) " +
                "stays unpainted and becomes a blocked zone."
        panel.addView(info)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        addButton(row, "Clear") { view.clear() }
        addButton(row, "Generate mask") { generate() }
        addButton(row, "Cancel") { finish() }
        panel.addView(row)

        val lp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.gravity = Gravity.BOTTOM
        root.addView(panel, lp)

        setContentView(root)
        goEdgeToEdge()
    }

    private fun addButton(parent: LinearLayout, label: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 15f
        b.minHeight = dp(52)
        b.setOnClickListener { onClick() }
        val p = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        p.leftMargin = dp(4); p.rightMargin = dp(4)
        parent.addView(b, p)
        return b
    }

    private fun goEdgeToEdge() {
        try { window.setDecorFitsSystemWindows(false) } catch (t: Throwable) {}
        try {
            val a = window.attributes
            a.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            window.attributes = a
        } catch (t: Throwable) {}
        try {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } catch (t: Throwable) {}
    }

    private fun generate() {
        if (view.strokes.isEmpty()) {
            Toast.makeText(this, "Draw over the working areas first", Toast.LENGTH_SHORT).show()
            return
        }
        val (rects, deadFrac, funcFrac) = computeDeadRects()
        if (funcFrac < MIN_FUNCTIONAL_FRAC) {
            Toast.makeText(
                this,
                "Only ${(funcFrac * 100).toInt()}% painted — cover more of the working area first",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        if (rects.isEmpty()) {
            Toast.makeText(this, "No dead zones found — nothing to block", Toast.LENGTH_LONG).show()
            return
        }
        val pct = (deadFrac * 100).toInt()
        AlertDialog.Builder(this)
            .setTitle("Block dead zones?")
            .setMessage("Found ${rects.size} dead zone(s) covering ~$pct% of the screen. Apply as the active mask?")
            .setPositiveButton("Apply") { d, _ ->
                d.dismiss()
                MaskStore.save(this, rects)
                if (Settings.canDrawOverlays(this)) {
                    startForegroundService(
                        Intent(this, BlockerService::class.java).setAction(BlockerService.ACTION_START)
                    )
                    Toast.makeText(this, "Dead zones blocked (${rects.size}) — blocking ON", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Saved — grant overlay permission, then Start blocking", Toast.LENGTH_LONG).show()
                }
                finish()
            }
            .setNegativeButton("Keep drawing") { d, _ -> d.dismiss() }
            .show()
    }

    /** Rasterize strokes → functional grid → dilate → invert → merge dead rects.
     *  Returns (dead rects in px, dead fraction, functional fraction). */
    private fun computeDeadRects(): Triple<List<Rect>, Float, Float> {
        val cols = ceil(screenW.toFloat() / CELL_PX).toInt()
        val rows = ceil(screenH.toFloat() / CELL_PX).toInt()
        val n = cols * rows

        // Paint strokes onto a cols x rows bitmap; any covered cell = functional.
        val bmp = Bitmap.createBitmap(cols, rows, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.scale(cols.toFloat() / screenW, rows.toFloat() / screenH)
        val paint = Paint().apply {
            color = Color.RED
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            isAntiAlias = false
        }
        for (s in view.strokes) {
            paint.strokeWidth = s.width
            c.drawPath(s.path, paint)
        }
        val func = BooleanArray(n)
        var painted = 0
        for (r in 0 until rows) for (col in 0 until cols) {
            if (Color.alpha(bmp.getPixel(col, r)) != 0) { func[r * cols + col] = true; painted++ }
        }
        bmp.recycle()

        // Dilate functional cells by DILATE_PX (in cells) so gaps between strokes fill in.
        val rad = max(0, Math.round(DILATE_PX.toFloat() / CELL_PX))
        val dil = if (rad == 0) func else dilate(func, cols, rows, rad)

        // Invert: cells not functional = dead.
        val dead = BooleanArray(n)
        for (i in 0 until n) dead[i] = !dil[i]

        // Electrode logic: a dead spot usually means a whole row/column line of
        // electrodes. Complete any grid row or column that is mostly dead so it
        // spans the full width / height (an entire row, or an entire column).
        for (r in 0 until rows) {
            var d = 0
            for (col in 0 until cols) if (dead[r * cols + col]) d++
            if (d.toFloat() / cols >= ROW_COL_FILL_FRAC) {
                for (col in 0 until cols) dead[r * cols + col] = true
            }
        }
        for (col in 0 until cols) {
            var d = 0
            for (r in 0 until rows) if (dead[r * cols + col]) d++
            if (d.toFloat() / rows >= ROW_COL_FILL_FRAC) {
                for (r in 0 until rows) dead[r * cols + col] = true
            }
        }

        var deadCount = 0
        for (i in 0 until n) if (dead[i]) deadCount++

        val rects = mergeDead(dead, cols, rows)
        return Triple(rects, deadCount.toFloat() / n, painted.toFloat() / n)
    }

    private fun dilate(src: BooleanArray, cols: Int, rows: Int, rad: Int): BooleanArray {
        val out = BooleanArray(cols * rows)
        for (r in 0 until rows) for (col in 0 until cols) {
            if (!src[r * cols + col]) continue
            val r0 = max(0, r - rad); val r1 = min(rows - 1, r + rad)
            val c0 = max(0, col - rad); val c1 = min(cols - 1, col + rad)
            for (rr in r0..r1) for (cc in c0..c1) out[rr * cols + cc] = true
        }
        return out
    }

    /** Merge dead cells into rectangles: horizontal runs, then identical runs merged vertically. */
    private fun mergeDead(dead: BooleanArray, cols: Int, rows: Int): List<Rect> {
        class Grow(val c0: Int, val c1: Int, val r0: Int, var r1: Int)
        val all = ArrayList<Grow>()
        var prev = HashMap<Long, Grow>()
        for (r in 0 until rows) {
            val cur = HashMap<Long, Grow>()
            var col = 0
            while (col < cols) {
                if (dead[r * cols + col]) {
                    val start = col
                    while (col < cols && dead[r * cols + col]) col++
                    val end = col - 1
                    val key = (start.toLong() shl 32) or end.toLong()
                    val g = prev[key]
                    if (g != null && g.r1 == r - 1) { g.r1 = r; cur[key] = g }
                    else { val ng = Grow(start, end, r, r); all.add(ng); cur[key] = ng }
                } else col++
            }
            prev = cur
        }
        return all.map {
            Rect(
                it.c0 * CELL_PX, it.r0 * CELL_PX,
                min((it.c1 + 1) * CELL_PX, screenW), min((it.r1 + 1) * CELL_PX, screenH)
            )
        }.filter { !it.isEmpty }
    }

    // ------------------------------------------------------------ the canvas

    private inner class MapView(context: Context) : View(context) {
        val strokes = ArrayList<Stroke>()
        private var current: Stroke? = null
        private val line = Paint().apply {
            color = Color.argb(200, 40, 170, 90)  // green = confirmed functional
            style = Paint.Style.STROKE
            strokeWidth = BRUSH_PX
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            isAntiAlias = true
        }
        private val hint = Paint().apply {
            color = Color.rgb(150, 150, 158); textSize = 34f; isAntiAlias = true
        }

        init { setBackgroundColor(Color.WHITE) }

        fun clear() { strokes.clear(); current = null; invalidate() }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            // First pointer only: ghost touches arrive as extra pointers and are ignored.
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    val s = Stroke(BRUSH_PX); s.add(event.rawX, event.rawY); current = s
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    val s = current ?: return true
                    val gx = event.rawX - s.lastX(); val gy = event.rawY - s.lastY()
                    if (gx * gx + gy * gy >= 9f) { s.add(event.rawX, event.rawY); invalidate() }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    current?.let { it.add(event.rawX, event.rawY); strokes.add(it) }
                    current = null
                    invalidate()
                }
            }
            return true
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            for (s in strokes) canvas.drawPath(s.path, line)
            current?.let { canvas.drawPath(it.path, line) }
            if (strokes.isEmpty() && current == null) {
                canvas.drawText("Paint the working areas (green). Blank = dead = blocked.", 40f, screenH * 0.5f, hint)
            }
        }
    }
}
