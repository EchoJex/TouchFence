package dev.solo.touchfence

import android.content.Context
import android.graphics.Rect

/**
 * Saves and loads the blocked rectangles.
 *
 * Storage format is deliberately dumb: one rectangle per line, "left,top,right,bottom"
 * in absolute portrait screen pixels (Pixel 7 Pro portrait = 1440 x 3120).
 */
object MaskStore {

    /**
     * ESCAPE HATCH / HAND-EDIT ZONE.
     *
     * If this list is NOT empty, it is used instead of whatever was drawn in the app.
     * Lets you hardcode zones in code without touching the drawing UI at all.
     * Coordinates are absolute screen pixels in portrait: Rect(left, top, right, bottom).
     *
     * Example — block a 1440x400 band across the very top of the screen:
     *   val MANUAL_OVERRIDE: List<Rect> = listOf(Rect(0, 0, 1440, 400))
     */
    val MANUAL_OVERRIDE: List<Rect> = listOf()

    private const val PREFS = "mask"
    private const val KEY = "rects"

    fun save(context: Context, rects: List<Rect>) {
        val text = rects.joinToString("\n") { "${it.left},${it.top},${it.right},${it.bottom}" }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY, text).apply()
    }

    fun load(context: Context): List<Rect> {
        if (MANUAL_OVERRIDE.isNotEmpty()) return MANUAL_OVERRIDE

        val text = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, null) ?: return emptyList()

        return text.lines().mapNotNull { line ->
            val p = line.split(",")
            if (p.size != 4) return@mapNotNull null
            try {
                Rect(p[0].trim().toInt(), p[1].trim().toInt(), p[2].trim().toInt(), p[3].trim().toInt())
            } catch (e: NumberFormatException) {
                null
            }
        }.filter { !it.isEmpty }
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().remove(KEY).apply()
    }
}
