package dev.solo.touchfence

import android.content.Context
import android.graphics.Path
import android.graphics.Rect

/**
 * One freeform brush stroke: a polyline of points plus its own brush width.
 * The Path mirror is only for rendering; the points are the real data.
 */
class Stroke(var width: Float) {
    val pts = ArrayList<Float>() // x0, y0, x1, y1, ...
    val path = Path()

    fun add(x: Float, y: Float) {
        if (pts.isEmpty()) path.moveTo(x, y) else path.lineTo(x, y)
        pts.add(x)
        pts.add(y)
    }

    fun lastX(): Float = pts[pts.size - 2]
    fun lastY(): Float = pts[pts.size - 1]

    fun rebuildPath() {
        path.reset()
        var i = 0
        while (i + 1 < pts.size) {
            if (i == 0) path.moveTo(pts[0], pts[1]) else path.lineTo(pts[i], pts[i + 1])
            i += 2
        }
    }
}

/**
 * Persistence. Two things are stored:
 *  - the final blocked rectangles (what BlockerService reads), and
 *  - the "draft": the strokes as drawn plus the D-pad offset, so the editor
 *    can restore your drawing exactly where you drew it and drop the mask
 *    back where it was.
 *
 * Formats are deliberately dumb text. Rects: one per line "l,t,r,b" in
 * absolute portrait pixels (Pixel 7 Pro portrait = 1440 x 3120).
 */
object MaskStore {

    /**
     * ESCAPE HATCH / HAND-EDIT ZONE.
     *
     * If this list is NOT empty, it is used instead of whatever was drawn in
     * the app. Coordinates are absolute portrait pixels: Rect(left, top,
     * right, bottom).
     *
     * Example — block a 1440x400 band across the very top of the screen:
     *   val MANUAL_OVERRIDE: List<Rect> = listOf(Rect(0, 0, 1440, 400))
     */
    val MANUAL_OVERRIDE: List<Rect> = listOf()

    private const val PREFS = "mask"
    private const val KEY_RECTS = "rects"
    private const val KEY_LAST = "rects_last"
    private const val KEY_DRAFT = "draft"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ------------------------------------------------------------ final rects

    fun save(context: Context, rects: List<Rect>) {
        val text = rects.joinToString("\n") { "${it.left},${it.top},${it.right},${it.bottom}" }
        val p = prefs(context)
        val prev = p.getString(KEY_RECTS, null)
        val e = p.edit()
        if (prev != null && prev.isNotBlank()) e.putString(KEY_LAST, prev)
        e.putString(KEY_RECTS, text).apply()
    }

    /** Restores the most recent previously-active mask; false if none exists. */
    fun recallLast(context: Context): Boolean {
        val p = prefs(context)
        val last = p.getString(KEY_LAST, null) ?: return false
        if (last.isBlank()) return false
        p.edit().putString(KEY_RECTS, last).apply()
        return true
    }

    fun load(context: Context): List<Rect> {
        if (MANUAL_OVERRIDE.isNotEmpty()) return MANUAL_OVERRIDE

        val text = prefs(context).getString(KEY_RECTS, null) ?: return emptyList()
        return text.lines().mapNotNull { line ->
            val p = line.split(",")
            if (p.size != 4) return@mapNotNull null
            try {
                Rect(p[0].trim().toInt(), p[1].trim().toInt(), p[2].trim().toInt(), p[3].trim().toInt())
            } catch (e: NumberFormatException) {
                null
            }
        }.filter { !it.isEmpty }
    }

    fun clear(context: Context) {
        val p = prefs(context)
        val prev = p.getString(KEY_RECTS, null)
        val e = p.edit()
        if (prev != null && prev.isNotBlank()) e.putString(KEY_LAST, prev)
        e.remove(KEY_RECTS).remove(KEY_DRAFT).apply()
    }

    // ------------------------------------------------------------ import

    /**
     * Imports mask data as a list of rectangles — deliberately simple so any
     * past or future export keeps importing. Accepts "M,i,l,t,r,b" rows and
     * bare "l,t,r,b" lines; every other line is ignored.
     * Returns how many rectangles were imported.
     */
    fun importText(context: Context, text: String): Int {
        val rects = mutableListOf<Rect>()
        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val tokens = line.split(",")
            val nums = tokens.mapNotNull { it.trim().toFloatOrNull() }
            val quad = when {
                tokens[0] == "M" && nums.size >= 5 -> nums.takeLast(4)
                tokens[0].toFloatOrNull() != null && nums.size == 4 -> nums
                else -> null
            } ?: continue
            val r = Rect(
                quad[0].toInt(), quad[1].toInt(), quad[2].toInt(), quad[3].toInt()
            )
            if (!r.isEmpty && r.left >= 0 && r.top >= 0 && r.right <= 20000 && r.bottom <= 20000) {
                rects.add(r)
            }
        }
        if (rects.isNotEmpty()) save(context, rects)
        return rects.size
    }

    // ------------------------------------------------------------ draft

    /** Draft format: first line "offset:x,y"; then one stroke per line as "width;x,y;x,y;...". */
    fun saveDraft(context: Context, strokes: List<Stroke>, offsetX: Int, offsetY: Int) {
        val sb = StringBuilder()
        sb.append("offset:").append(offsetX).append(',').append(offsetY)
        for (s in strokes) {
            sb.append('\n').append(s.width)
            var i = 0
            while (i + 1 < s.pts.size) {
                sb.append(';').append(s.pts[i]).append(',').append(s.pts[i + 1])
                i += 2
            }
        }
        prefs(context).edit().putString(KEY_DRAFT, sb.toString()).apply()
    }

    /** Returns the saved strokes and offset; empty list and (0,0) if none or unreadable. */
    fun loadDraft(context: Context): Triple<MutableList<Stroke>, Int, Int> {
        val strokes = mutableListOf<Stroke>()
        var ox = 0
        var oy = 0
        val text = prefs(context).getString(KEY_DRAFT, null)
            ?: return Triple(strokes, 0, 0)
        try {
            for (line in text.lines()) {
                if (line.startsWith("offset:")) {
                    val p = line.removePrefix("offset:").split(",")
                    if (p.size == 2) {
                        ox = p[0].trim().toIntOrNull() ?: 0
                        oy = p[1].trim().toIntOrNull() ?: 0
                    }
                } else if (line.isNotBlank()) {
                    val parts = line.split(";")
                    val w = parts[0].toFloatOrNull() ?: continue
                    val s = Stroke(w)
                    for (j in 1 until parts.size) {
                        val xy = parts[j].split(",")
                        if (xy.size != 2) continue
                        val x = xy[0].toFloatOrNull() ?: continue
                        val y = xy[1].toFloatOrNull() ?: continue
                        s.pts.add(x)
                        s.pts.add(y)
                    }
                    if (s.pts.size >= 2) {
                        s.rebuildPath()
                        strokes.add(s)
                    }
                }
            }
        } catch (t: Throwable) {
            return Triple(mutableListOf(), 0, 0)
        }
        return Triple(strokes, ox, oy)
    }
}
