package dev.solo.touchfence

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Rect
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager

/**
 * Foreground service that keeps one small overlay window alive per blocked rectangle.
 * Each window swallows every touch inside its bounds; everything outside passes through
 * untouched. The notification carries the two escape hatches: Pause 10s and Stop.
 */
class BlockerService : Service() {

    companion object {
        @Volatile var RUNNING = false

        const val ACTION_START = "dev.solo.touchfence.START"
        const val ACTION_PAUSE = "dev.solo.touchfence.PAUSE"
        const val ACTION_STOP = "dev.solo.touchfence.STOP"

        /** How long the Pause notification action lifts the mask, in milliseconds. */
        const val PAUSE_MS = 10_000L

        /** Alpha-red tint of the blocked zones. Raise for more visible, 0x00 for invisible. */
        const val ZONE_COLOR = 0x28FF3B30

        /** Every blocked rectangle is its own system window, and windows are
         *  expensive: each one joins the system's input routing, so dozens of
         *  them make the whole phone's touch handling sluggish. Above this
         *  count, nearby rectangles merge into bounding boxes until it fits. */
        const val MAX_WINDOWS = 32

        /** Ceiling on the empty area (in px²) a single merge may add. A merge
         *  that would bridge a wider gap than this is skipped, so two separate
         *  damaged zones never fuse into one bounding box that swallows the
         *  clear screen between (and above) them. When no merge stays under
         *  this cap, the window count is allowed to exceed [MAX_WINDOWS] —
         *  correct pass-through beats a tidy window count. */
        const val MAX_MERGE_WASTE = 40_000L

        private const val CHANNEL_ID = "blocking"
        private const val NOTIF_ID = 1
    }

    /** A view whose only job in life is to eat touches. */
    private class WallView(context: Context) : View(context) {
        init { setBackgroundColor(ZONE_COLOR) }
        override fun onTouchEvent(event: MotionEvent): Boolean = true
    }

    private val handler = Handler(Looper.getMainLooper())
    private val overlays = mutableListOf<View>()
    private var paused = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_PAUSE -> {
                if (RUNNING) pauseFor(PAUSE_MS)
                return START_STICKY
            }
            else -> {
                start()
                return START_STICKY
            }
        }
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        handler.removeCallbacksAndMessages(null)
        paused = false
        createChannel()
        goForeground(activeNotification())
        addOverlays()
        RUNNING = true
    }

    private fun pauseFor(ms: Long) {
        handler.removeCallbacksAndMessages(null)
        removeOverlays()
        paused = true
        notify(pausedNotification())
        handler.postDelayed({
            paused = false
            addOverlays()
            notify(activeNotification())
        }, ms)
    }

    /** Greedy merge: repeatedly union the two rectangles whose combined
     *  bounding box wastes the least area, until at most [MAX_WINDOWS] remain
     *  or no remaining merge stays within [MAX_MERGE_WASTE]. The waste cap is
     *  what keeps a merge from spanning the clear gap between two separate
     *  damaged zones — the cause of touches dying above/around the mask. */
    private fun consolidate(input: List<Rect>): List<Rect> {
        if (input.size <= MAX_WINDOWS) return input
        val rects = ArrayList<Rect>(input.size)
        for (r in input) rects.add(Rect(r))
        while (rects.size > MAX_WINDOWS) {
            var bi = 0
            var bj = 1
            var best = Long.MAX_VALUE
            for (i in 0 until rects.size) {
                val a = rects[i]
                for (j in i + 1 until rects.size) {
                    val b = rects[j]
                    val w = (maxOf(a.right, b.right) - minOf(a.left, b.left)).toLong()
                    val h = (maxOf(a.bottom, b.bottom) - minOf(a.top, b.top)).toLong()
                    val waste = w * h -
                            a.width().toLong() * a.height() -
                            b.width().toLong() * b.height()
                    if (waste < best) {
                        best = waste
                        bi = i
                        bj = j
                    }
                }
            }
            // If even the cheapest available merge would bridge a wider gap
            // than the cap, stop here and keep the extra windows: covering
            // clear screen is worse than routing a few more overlays.
            if (best > MAX_MERGE_WASTE) break
            val merged = rects.removeAt(bj) // bj > bi, so bi stays valid
            rects[bi].union(merged)
        }
        return rects
    }

    private fun addOverlays() {
        removeOverlays()
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val rects = consolidate(MaskStore.load(this))
        for (rect in rects) {
            val view = WallView(this)
            val lp = WindowManager.LayoutParams(
                rect.width(),
                rect.height(),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = rect.left
            lp.y = rect.top
            try {
                wm.addView(view, lp)
                overlays.add(view)
            } catch (e: Exception) {
                // Window could not be added (e.g. permission revoked mid-flight); skip it.
            }
        }
    }

    private fun removeOverlays() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        for (view in overlays) {
            try {
                wm.removeView(view)
            } catch (e: Exception) {
                // Already gone; ignore.
            }
        }
        overlays.clear()
    }

    // ---------------------------------------------------------------- notification

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Blocking", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun goForeground(n: Notification) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun notify(n: Notification) {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, n)
    }

    private fun servicePending(requestCode: Int, action: String): PendingIntent {
        val i = Intent(this, BlockerService::class.java).setAction(action)
        return PendingIntent.getService(this, requestCode, i, PendingIntent.FLAG_IMMUTABLE)
    }

    private fun baseBuilder(): Notification.Builder {
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                    "Pause ${PAUSE_MS / 1000}s", servicePending(1, ACTION_PAUSE)
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_delete),
                    "Stop", servicePending(2, ACTION_STOP)
                ).build()
            )
    }

    private fun activeNotification(): Notification = baseBuilder()
        .setContentTitle("TouchFence is blocking")
        .setContentText("Dead zones active. Pause ${PAUSE_MS / 1000}s to lift them briefly.")
        .build()

    private fun pausedNotification(): Notification = baseBuilder()
        .setContentTitle("TouchFence paused")
        .setContentText("Zones lift for ${PAUSE_MS / 1000} seconds, then come back.")
        .build()

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removeOverlays()
        RUNNING = false
        super.onDestroy()
    }
}
