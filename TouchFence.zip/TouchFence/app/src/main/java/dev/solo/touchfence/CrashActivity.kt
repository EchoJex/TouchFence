package dev.solo.touchfence

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Shown when the app crashes. Runs in its own process so it survives the main
 * process dying. The Copy button is at the bottom, in the trustworthy half of
 * the screen; the trace itself scrolls.
 */
class CrashActivity : Activity() {

    private fun dp(v: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics
    ).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val trace = intent.getStringExtra("trace") ?: "No trace captured"

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.rgb(28, 14, 14))
        root.setPadding(dp(16), dp(40), dp(16), dp(24))

        val title = TextView(this)
        title.text = "TouchFence crashed"
        title.textSize = 22f
        title.setTypeface(null, Typeface.BOLD)
        title.setTextColor(Color.WHITE)
        root.addView(title)

        val scroll = ScrollView(this)
        val traceView = TextView(this)
        traceView.text = trace
        traceView.textSize = 12f
        traceView.setTextColor(Color.rgb(255, 180, 180))
        traceView.typeface = Typeface.MONOSPACE
        traceView.setTextIsSelectable(true)
        scroll.addView(traceView)
        val scrollLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        )
        scrollLp.topMargin = dp(12)
        scrollLp.bottomMargin = dp(12)
        root.addView(scroll, scrollLp)

        val copy = Button(this)
        copy.text = "Copy error"
        copy.isAllCaps = false
        copy.textSize = 17f
        copy.minHeight = dp(56)
        copy.setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("TouchFence crash", trace))
            Toast.makeText(this, "Copied \u2014 paste it to Claude", Toast.LENGTH_SHORT).show()
        }
        root.addView(
            copy,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        setContentView(root)
    }
}
