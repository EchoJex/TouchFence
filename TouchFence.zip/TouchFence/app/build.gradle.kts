plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.solo.touchfence"
    compileSdk = 34

    defaultConfig {
        applicationId = "dev.solo.touchfence"
        minSdk = 33
        targetSdk = 34
        versionCode = 6
        versionName = "1.4"
    }

    // A fixed key committed with the project, so every build — on any machine
    // or CI runner — carries the same signature and installs over the last.
    signingConfigs {
        create("shared") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("shared")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
    }
}

// Intentionally empty: the app uses only framework APIs, so nothing to download,
// nothing to version-conflict, nothing to break.
dependencies {
}
