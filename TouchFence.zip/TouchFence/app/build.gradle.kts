plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "dev.solo.touchfence"
    compileSdk = 34

    defaultConfig {
        applicationId = "dev.solo.touchfence"
        minSdk = 33
        targetSdk = 34
        // CI passes -PversionCodeOverride=<n> so every build gets a unique,
        // increasing versionCode (the in-app updater compares against it).
        // Local builds fall back to the pinned schema value.
        versionCode = (project.findProperty("versionCodeOverride") as String?)?.toIntOrNull() ?: 13
        versionName = "2.1"
    }

    // A fixed key committed with the project, so every build — on any machine
    // or CI runner — carries the same signature and installs over the last.
    signingConfigs {
        create("shared") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("shared")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("shared")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    lint {
        abortOnError = false
    }
}

// Intentionally empty: the app uses only framework APIs, so nothing to download,
// nothing to version-conflict, nothing to break.
dependencies {
}
