# TouchFence

A personal touch-blocker for a cracked screen. Draw a freeform shape in the
working (bottom) half of the screen, the app converts it into at most 128
rectangles, and a D-pad nudges the mask up over the damaged area. A foreground
service then keeps one tiny overlay window per rectangle alive, eating every
touch inside the mask while everything outside behaves normally.

No third-party dependencies and no ads. Ten Kotlin files. The app's only
network use is the built-in updater, which pulls new builds from this repo's
GitHub Releases (framework HTTP APIs — still nothing third-party).

## Build and install

1. Install Android Studio (free) and open this folder (File > Open).
2. Let it sync — it will download Gradle 8.4 and SDK 34 on first run.
3. On the phone: Settings > About phone > tap Build number 7 times, then
   Developer options > enable USB debugging.
4. Plug in the phone, accept the debugging prompt, press Run (green ▶).

Command line alternative: `./gradlew installDebug` with the phone plugged in.

## Using it

1. Open TouchFence, allow notifications, tap "Grant overlay permission"
   (Settings opens — enable it for TouchFence, go back).
2. Tap "Draw or edit mask". Scribble or circle the shape of the dead zone
   anywhere below the dashed line. Thick scribbles fill; closed loops fill
   their interior. Undo/Clear as needed, then "Done".
3. The shape becomes red rectangles. Hold the D-pad arrows to slide the whole
   mask up onto the damaged area (Step toggles 20 px / 120 px). "Save mask".
4. Tap "Start blocking". The zones tint faint red and eat all touches.

The persistent notification has **Pause 10s** (lifts the mask briefly — your
escape hatch if a zone covers something you need) and **Stop**.

## Updating (no computer)

Every push builds an APK and publishes it as this repo's **latest GitHub
Release**. Two ways to get it onto the phone:

- **In-app (one tap):** open TouchFence → **Check for updates**. It asks GitHub
  for the newest build and, if there is one, downloads it and shows the system
  "Update?" prompt — tap Install. No re-download, no unzip, no uninstall (the
  shared keystore installs the new build straight over the old). The first time,
  Android asks you to allow TouchFence to "install unknown apps"; the button
  deep-links you there, then works on the next tap.
- **Manually:** open the repo's **Releases** page and download
  `TouchFence-<n>.apk` directly (it's a plain APK, not a zip), then tap it.

Note: the in-app updater only exists from the build that introduced it onward,
so install that one first (via Releases), and updates are one-tap after that.

## Tweakables

All in one place at the top of each file:

`DrawMaskActivity.kt` — `GUARD_FRACTION` (how much of the screen accepts
drawing, default bottom 50%), `MAX_RECTS` (128), `MIN_BRUSH_PX` /
`MAX_BRUSH_PX` / `DEFAULT_BRUSH_PX` (brush slider range), `STEP_FINE` /
`STEP_COARSE` (D-pad step sizes), `START_CELL_PX` (rasterization resolution).

`BlockerService.kt` — `ZONE_COLOR` (tint of active zones; lower the leading
byte for more invisible), `PAUSE_MS` (pause length).

`MaskStore.kt` — `MANUAL_OVERRIDE`: hardcode exact rectangles in code and skip
the drawing UI entirely. Example inside the file.

## Known limits (Android, not fixable in an app)

- Overlays cannot cover the lock screen, the status bar, or the notification
  shade — use fingerprint unlock if the crack sits over the PIN pad.
- The mask is portrait-only; keep auto-rotate off while blocking.
- If you ever block yourself out completely: reboot into safe mode
  (hold power, then long-press "Power off"), which disables all overlays.
